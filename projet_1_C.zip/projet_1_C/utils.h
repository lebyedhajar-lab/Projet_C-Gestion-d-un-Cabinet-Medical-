#ifndef UTILS_H
#define UTILS_H
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define CLR_RESET  "\x1b[0m"
#define RED        "\x1b[31m"
#define GREEN      "\x1b[32m"
#define YELLOW     "\x1b[33m"
#define BLUE       "\x1b[34m"
#define MAGENTA    "\x1b[35m"
#define CYAN       "\x1b[36m"
#define WHITE      "\x1b[37m"

// Couleurs Grasses (Bold)
#define BOLD_RED     "\x1b[1;31m"
#define BOLD_GREEN   "\x1b[1;32m"
#define BOLD_YELLOW  "\x1b[1;33m"
#define BOLD_BLUE    "\x1b[1;34m"
#define BOLD_CYAN    "\x1b[1;36m"
#define BOLD_WHITE   "\x1b[1;37m"
#define C_CYAN    "\x1b[36m"
#define C_B_CYAN  "\x1b[1;36m"
#define C_WHITE   "\x1b[37m"
#define C_B_WHITE "\x1b[1;37m"
#define C_GRAY    "\x1b[90m"
#define C_RESET   "\x1b[0m"
#define C_BOLD  "\x1b[1m"
#define C_B_YELLOW "\x1b[1;33m"
// Fonds
#define BG_BLUE    "\x1b[44m"
#define BG_CYAN    "\x1b[46m"

typedef struct {
    int jour;
    int mois;
    int annee;
} Date;

void clearBuffer() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}
void clearScreen() {
    #ifdef _WIN32
        system("cls");
    #else
        system("clear");
    #endif 
}
void pauseScreen() {
    printf("\nAppuyez sur Entree pour continuer...");
    clearBuffer();
    clearScreen();
}
int lireEntier(const char *message) {
    int valeur;
    printf("%s", message);
    while (scanf("%d", &valeur) != 1) {
        printf("Erreur! Entrez un nombre valide: ");
        clearBuffer();
    }
    clearBuffer();
    return valeur;
}
void lireChaine(char *dest, int taille, const char *message) {
    printf("%s", message);
    fgets(dest, taille, stdin);
    dest[strcspn(dest, "\n")] = 0;  
}

float lireFloat(const char *message) {
    float valeur;
    printf("%s", message);
    while (scanf("%f", &valeur) != 1) {
        printf("Erreur! Entrez un montant valide: ");
        int c; while ((c = getchar()) != '\n' && c != EOF); // Vide le buffer
    }
    int c; while ((c = getchar()) != '\n' && c != EOF); // Vide le buffer APRES la lecture
    return valeur;
}
void dessinerEnTete(const char* titre) {
    clearScreen();
    printf(BOLD_CYAN "+============================================================+\n");
    printf("|" BOLD_WHITE " %-58s " BOLD_CYAN "|\n", titre);
    printf("+============================================================+\n" CLR_RESET);
}
void promptElegante(const char* message) {
    printf("\n" C_BOLD C_CYAN "    %s > " C_RESET, message);
}

void messageSucces(const char* message) {
    printf("\n" C_B_CYAN "    [ V ] " C_WHITE "%s\n" C_RESET, message);
    Sleep(1000);
}
void afficherEnteteElegante(const char* titre) {
    clearScreen();
    printf("\n\n");
    printf(C_CYAN "  ============================================================\n" C_RESET);
    printf(C_BOLD C_WHITE "    %s\n" C_RESET, titre);
    printf(C_CYAN "  ============================================================\n" C_RESET);
}

void afficherLigneOption(const char* numero, const char* label) {
    // Affiche une option avec un alignement parfait
    printf(C_CYAN "    [ " C_WHITE "%s" C_CYAN " ] " C_RESET " %-40s\n", numero, label);
}

// Un petit symbole discret pour le luxe
#define SYMB_POINT "·"

void afficherInterfaceMed(const char* titre) {
    clearScreen();
    // Ligne de vie discrète (Pulse) en haut
    printf("\n" C_GRAY "  --/\\--\\/-----------/\\----------" C_CYAN "======" C_GRAY "------------------\n" C_RESET);
    
    // Titre centré avec élégance
    printf(C_B_WHITE "           M E D I C A L   S O L U T I O N S\n" C_RESET);
    printf(C_GRAY    "           Portail d'administration : " C_B_CYAN "%s\n" C_RESET, titre);
    
    printf(C_CYAN "  ============================================================\n\n" C_RESET);
}

void afficherOption(const char* id, const char* titre, const char* desc) {
    printf(C_B_CYAN "    %s " C_B_WHITE " %s\n" C_RESET, id, titre);
    printf(C_GRAY   "       %s\n\n" C_RESET, desc);
}

void maPause() {
    printf(C_GRAY "\n    [ Appuyez sur une touche pour continuer... ]" C_RESET);
    fflush(stdin); // Pour certains compilateurs
    _getch();      // Attend une touche
}
void pauseSecretaire() {
    printf(C_GRAY "\n    [ Appuyez sur une touche pour continuer... ]" C_RESET);
    fflush(stdin); // Vide le tampon
    _getch();      // Attend une touche
}

#endif 