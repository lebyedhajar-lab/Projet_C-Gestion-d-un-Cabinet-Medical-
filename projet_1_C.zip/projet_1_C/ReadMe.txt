===========================================================
     PROJET : SYSTÈME DE GESTION CLINIQUE « EL ALAMI »
===========================================================

DESCRIPTION :
Application console développée en langage C pour la gestion
complète d'un cabinet médical (Patients, Secrétariat, Médecin).

-----------------------------------------------------------
1. CONFIGURATION REQUISE
-----------------------------------------------------------
- Système d'exploitation : Windows (impératif pour <windows.h> et <conio.h>)
- Compilateur : GCC (MinGW) ou tout IDE supportant le C (Code::Blocks, Dev-C++, VS Code)
- Langage : C11 ou supérieur

-----------------------------------------------------------
2. COMPILATION ET EXÉCUTION
-----------------------------------------------------------
Pour compiler manuellement via le terminal :
   gcc main.c -o clinique_alami.exe

Pour lancer l'application :
   ./clinique_alami.exe

-----------------------------------------------------------
3. CODES D'ACCÈS (IMPORTANT)
-----------------------------------------------------------
Pour tester les différents modules, utilisez les accès suivants :

ESPACE SECRÉTAIRE :
   - Login : ILHAM
   - Pass  : 1234

ESPACE MÉDECIN :
   - Identifiant : 1
   - Pass        : H12345

ESPACE PATIENT :
   - Créez un nouveau compte via l'option "Inscription"
   - L'identifiant vous sera attribué automatiquement par le système.

-----------------------------------------------------------
4. STRUCTURE DES FICHIERS
-----------------------------------------------------------
- main.c          : Programme principal (Menu et logique)
- patients.txt    : Base de données des patients
- factures.txt    : Registre comptable
- rdv_confirmes.txt : Agenda médical
- [etc...]

-----------------------------------------------------------
5. FONCTIONNALITÉS CLÉS
-----------------------------------------------------------
- Interface en couleurs ANSI (Thème Clinical Silver).
- Masquage des mots de passe par astérisques.
- Validation automatique des dates et des emails.
- Génération automatique de factures et calcul des impayés.
- Statistiques visuelles en barres ASCII.

-----------------------------------------------------------
DÉVELOPPÉ PAR : [Vos Noms]
ANNÉE : 2024/2025
===========================================================