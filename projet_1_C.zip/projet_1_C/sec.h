#ifndef SEC_H
#define SEC_H

#include "Patient.h"
#include "utils.h"

#define MAX_PATIENTS 100
#define FICHIER_DEMANDES_RDV "demandes_rdv.txt"
#define FICHIER_FACTURES "factures.txt"
#define FICHIER_PATIENTS "patients.txt"


typedef struct {
    char NOM[100];
    char CIN[20];
    char date_payement[11];
    float montant;
    float paye;
    float restant;
} Facture;

// Variables globales
extern Patient patients[MAX_PATIENTS];
extern int nb_patients;

// Fonctions utilitaires
void clearScreen();
void pauseScreen();
void afficherLigneSeparatrice(int longueur, char caractere);
void afficherTitreCentre(const char* titre, int largeur);
void afficherMessageSucces(const char* message);

// Fonctions principales
int loginSecretaire();
void espaceSecretaire();

// Charger Patients
void chargerPatients();

// Gestion des patients
void menuGestionPatients();
void afficherTousPatients();
void rechercherPatient();
void supprimerPatient();

// Gestion des RDV
void menuGestionRDV();
void listerToutesDemandes();
void listerDemandesEnAttente();
void deplacerDemande(int id_demande, char nouveauFichier[], char nouveauStatut[]);
void confirmerDemande();
void refuserDemande();

// Gestion de comptabilité
void menuGestionComptabilite();
void ajouterFacture();
void afficherToutesFactures();
void afficherUneFacture();
void enregistrerPaiement();
void afficherFacturesImpayees();

// Gestion des statistiques
void menuGestionStatistiques();
void afficherStatistiquesPatients();
void afficherStatistiquesRDV();
void afficherStatistiquesFinancieres();
void afficherStatistiquesGenerales();

#endif