#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <conio.h>
#include <windows.h> 

#include "utils.h"
#include "patient.h"
#include "sec.h"

#define LOGIN_SEC "ILHAM"
#define PASS_SEC  "1234"
#define FICHIER_FACTURES "factures.txt"
#define FICHIER_DEMANDES_RDV "demandes_rdv.txt"
#define FICHIER_CONFIRMES "demandes_confirmees.txt"
#define FICHIER_REFUS "demandes_refusees.txt"

#define CLR_RESET  "\x1b[0m"
#define RED        "\x1b[31m"
#define GREEN      "\x1b[32m"
#define YELLOW     "\x1b[33m"
#define BLUE       "\x1b[34m"
#define MAGENTA    "\x1b[35m"
#define CYAN       "\x1b[36m"
#define WHITE      "\x1b[37m"

#define BOLD_RED     "\x1b[1;31m"
#define BOLD_GREEN   "\x1b[1;32m"
#define BOLD_YELLOW  "\x1b[1;33m"
#define BOLD_BLUE    "\x1b[1;34m"
#define BOLD_CYAN    "\x1b[1;36m"
#define BOLD_WHITE   "\x1b[1;37m"
#define C_CYAN    "\x1b[36m"
#define C_B_CYAN  "\x1b[1;36m"
#define C_WHITE   "\x1b[37m"
#define C_B_WHITE "\x1b[1;37m"
#define C_GRAY    "\x1b[90m"
#define C_RESET   "\x1b[0m"
#define C_BOLD  "\x1b[1m"

#define BG_BLUE    "\x1b[44m"
#define BG_CYAN    "\x1b[46m"

#define SYMB_POINT ">"


void chargerPatients();
void afficherTousPatients();
void rechercherPatient();
void supprimerPatient();

// Prototypes Gestion RDV
void menuGestionRDV();
void listerToutesDemandes();
void listerDemandesEnAttente();
void confirmerDemande();
void refuserDemande();

// Prototypes Gestion Compta
void menuGestionComptabilite();
void ajouterFacture();
void afficherToutesFactures();
void afficherUneFacture();
void enregistrerPaiement();
void afficherFacturesImpayees();

// Prototypes Stats
void menuGestionStatistiques();
void afficherStatistiquesPatients();
void afficherStatistiquesRDV();
void afficherStatistiquesFinancieres();
void afficherStatistiquesGenerales();

void afficherEnteteElegante(const char* titre);
void afficherLigneOption(const char* numero, const char* label);
void promptElegante(const char* message);
void messageSucces(const char* message);
void afficherInterfaceMed(const char* titre);

// ==================== DECLARATIONS DES FONCTIONS ====================

// Fonctions utilitaires

void saisirMotDePasseMasque(char *motDePasse, int taille);

// Fonctions medecin
void afficherMedecin();
int connexionMedecin();
void modifierMedecin();
void EspaceMedecin();

// Fonctions patient
void EspacePatient();
void ajouterPatient();
void afficherPatients();
void rechercherPatient();
void modifierPatient();
void supprimerPatient();
int genererIdPatient();

// Fonctions dossier medical
void creerDossierMedical();
void afficherDossierMedical();
void afficherTousLesDossiers();
int dossierExiste(int idPatient);

// Fonctions consultation
void ajouterConsultation();
void afficherConsultations();
void rechercherConsultation();
void modifierConsultation();
void supprimerConsultation();
int genererIdConsultation();

// Fonction RDV
void afficherRendezVousConfirmes();

// Variables globales

Patient patients[MAX_PATIENTS];
int nb_patients = 0;

// ==================== ESPACE PATIENT ====================

int trouverPatient(int id) {
    for (int i = 0; i < nb_patients; i++) {
        if (patients[i].actif && patients[i].id_patient == id)
            return i;
    }
    return -1;
}

int genererNouvelID() {
    int max_id = 0;
    for (int i = 0; i < nb_patients; i++) {
        if (patients[i].id_patient > max_id) {
            max_id = patients[i].id_patient;
        }
    }
    return max_id + 1;
}

void sauvegarderPatients() {
    FILE *f = fopen(FICHIER_PATIENTS, "w"); 
    if (!f) return;

    for (int i = 0; i < nb_patients; i++) {
        if (patients[i].actif) {
            fprintf(f, "%d;%s;%s;%s;%s;%s;%s;%s;%s;%d\n",
                    patients[i].id_patient, 
                    patients[i].nom, 
                    patients[i].prenom, 
                    patients[i].cin,
                    patients[i].email, 
                    patients[i].date_naissance,
                    patients[i].sexe, 
                    patients[i].mot_de_passe, 
                    patients[i].telephone, 
                    patients[i].actif);
        }
    }
    fclose(f);
}
void chargerPatients0() {
    FILE *f = fopen(FICHIER_PATIENTS, "r");
    if (!f) {
        nb_patients = 0;
        return;
    }

    nb_patients = 0; 
    char ligne[1024]; 

    while (fgets(ligne, sizeof(ligne), f) != NULL) {
        if (nb_patients >= MAX_PATIENTS) break;

        ligne[strcspn(ligne, "\r\n")] = 0;
        if (strlen(ligne) < 10) continue;

        Patient p;
        int champs = sscanf(ligne, "%d;%49[^;];%49[^;];%19[^;];%99[^;];%19[^;];%9[^;];%49[^;];%19[^;];%d",
               &p.id_patient,
               p.nom,
               p.prenom,
               p.cin,
               p.email,
               p.date_naissance,
               p.sexe,
               p.mot_de_passe,
               p.telephone,
               &p.actif);

        if (champs >= 9) {
            patients[nb_patients] = p;
            nb_patients++;
        }
    }
    fclose(f);
}

// ==================== AUTHENTIFICATION ====================

int verifierLogin(int id, const char *mot_de_passe_saisi) {
    int index = trouverPatient(id);
    if (index == -1) return 0;

    if (strcmp(patients[index].mot_de_passe, mot_de_passe_saisi) == 0) {
        return 1;
    }
    return 0;
}

// 1. Vérifier si l'email contient '@' et '.'
int estEmailValide(const char *email) {
    char *at = strchr(email, '@');
    char *dot = strrchr(email, '.');
    
    // Il faut un @, un point, et le point doit être après le @
    if (at != NULL && dot != NULL && dot > at) {
        return 1; // Valide
    }
    return 0; // Invalide
}

// 2. Vérifier si le téléphone contient 10 chiffres (ex: 0600000000)
int estTelephoneValide(const char *tel) {
    if (strlen(tel) != 10) return 0; // Doit faire 10 caractères
    
    for (int i = 0; i < 10; i++) {
        if (!isdigit(tel[i])) return 0; // Doit être uniquement des chiffres
    }
    return 1;
}

// 3. Vérifier le format de date (YYYY-MM-DD) comme dans ton fichier
int estDateValide(const char *date) {
    if (strlen(date) != 10) return 0;
    if (date[4] != '-' || date[7] != '-') return 0;
    int a, m, j;
    if (sscanf(date, "%d-%d-%d", &a, &m, &j) != 3) return 0;
    if (a < 1900 || a > 2100) return 0;
    if (m < 1 || m > 12) return 0;
    if (j < 1 || j > 31) return 0;
    if ((m==4||m==6||m==9||m==11) && j>30) return 0;
    if (m==2) {
        int b = (a%4==0 && a%100!=0) || (a%400==0);
        if (j > (b?29:28)) return 0;
    }
    return 1;
}

int verifierSiDatePassee(const char *dateStr) {
    int a, m, j;
    sscanf(dateStr, "%d-%d-%d", &a, &m, &j);
    time_t t = time(NULL);
    struct tm *now = localtime(&t);
    int an = now->tm_year + 1900, mn = now->tm_mon + 1, jn = now->tm_mday;
    if (a < an) return 1;
    if (a > an) return 0;
    if (m < mn) return 1;
    if (m > mn) return 0;
    return (j <= jn);
}

int estHeureValide(const char *h) {
    if (strlen(h) != 5 || h[2] != ':') return 0;
    
    int hh, mm;
    if (sscanf(h, "%d:%d", &hh, &mm) != 2) return 0;

    // Vérification syntaxique
    if (hh < 0 || hh > 23 || mm < 0 || mm > 59) return 0;

    // Vérification créneau cabinet (Exemple: 08:00 à 18:00)
    if (hh < 8 || hh >= 18) {
        printf(C_GRAY "    [ i ] Le cabinet est ouvert de 08:00 a 18:00.\n" C_RESET);
        return 0;
    }
    return 1;
}

int verifierHeureFuture(const char *dateStr, const char *heureStr) {
    int a, m, j, hh, mm;
    sscanf(dateStr, "%d-%d-%d", &a, &m, &j);
    sscanf(heureStr, "%d:%d", &hh, &mm);

    time_t t = time(NULL);
    struct tm *now = localtime(&t);
    
    int an = now->tm_year + 1900, mn = now->tm_mon + 1, jn = now->tm_mday;
    int hn = now->tm_hour, minn = now->tm_min;

    // Si la date est aujourd'hui, on compare l'heure
    if (a == an && m == mn && j == jn) {
        if (hh < hn) return 0; // Heure passée
        if (hh == hn && mm <= minn) return 0; // Minute passée ou actuelle
    }
    return 1; // La date est future ou l'heure est future
}

// 4. Vérifier le sexe (F ou M uniquement)


int estSexeValide(const char *sexe) {
    // Vérifie que la chaîne n'est pas vide et fait 1 seul caractère
    if (strlen(sexe) != 1) return 0;
    
    // Vérifie si c'est M ou F (Majuscules)
    if (sexe[0] == 'M' || sexe[0] == 'F') {
        return 1;
    }
    return 0;
}

int inscrireNouveauPatient() {
    if (nb_patients >= MAX_PATIENTS) {
        printf(C_B_CYAN "\n    [ ! ] Capacite maximale de la clinique atteinte.\n" C_RESET);
        return -1;
    }

    Patient p;
    afficherEnteteElegante("I N S C R I P T I O N   N O U V E L L E");
    printf(C_GRAY "    Veuillez renseigner les informations suivantes :\n\n" C_RESET);

    p.id_patient = genererNouvelID();
    
    promptElegante("NOM DE FAMILLE"); 
    scanf("%s", p.nom);
    
    promptElegante("PRENOM"); 
    scanf("%s", p.prenom);

    promptElegante("CIN");
    scanf("%s", p.cin);
    do {
        promptElegante("EMAIL (ex: nom@mail.com)"); 
        scanf("%s", p.email);
    } while (!estEmailValide(p.email));

    do {
        promptElegante("DATE DE NAISSANCE (AAAA-MM-JJ)");
        scanf("%s", p.date_naissance);

        if (!estDateValide(p.date_naissance)) {
            printf(C_B_CYAN "    [ ! ] Format invalide ou date inexistante.\n" C_RESET);
        } else if (!verifierSiDatePassee(p.date_naissance)) {
            printf(C_B_CYAN "    [ ! ] La date ne peut pas etre dans le futur.\n" C_RESET);
        } else {
            break; 
        }
    } while (1);

    do {
        promptElegante("SEXE (M/F)"); 
        scanf("%s", p.sexe);

        // Convertir en majuscule au cas où l'utilisateur tape 'm' ou 'f'
        p.sexe[0] = toupper(p.sexe[0]);

        if (!estSexeValide(p.sexe)) {
            printf(C_B_CYAN "    [ ! ] Entree invalide. Veuillez saisir 'M' ou 'F'.\n" C_RESET);
        } else {
            break; // Saisie correcte
        }
    } while (1);

    promptElegante("TELEPHONE"); 
    scanf("%s", p.telephone);

    printf("\n" C_B_WHITE "    CREATION DU MOT DE PASSE : " C_B_CYAN);
    scanf("%s", p.mot_de_passe);

    p.actif = 1;
    patients[nb_patients++] = p;
    sauvegarderPatients();

    return p.id_patient;
}

int loginPatient() {
    int id;
    char mot_de_passe[20];

    afficherEnteteElegante("C O N N E X I O N   P A T I E N T");
    printf(C_GRAY "    Acces securise a votre dossier personnel.\n\n" C_RESET);
    
    printf(C_WHITE "    IDENTIFIANT PATIENT   : " C_B_CYAN);
    if (scanf("%d", &id) != 1) { 
        while(getchar() != '\n'); 
        return -1; 
    }
    while(getchar() != '\n'); // Nettoyage buffer

    printf(C_WHITE "    MOT DE PASSE          : " C_B_CYAN);
    saisirMotDePasseMasque(mot_de_passe, 20);

    printf(C_GRAY "\n    Verification de l'identite..." C_RESET);
    Sleep(600);

    if (verifierLogin(id, mot_de_passe)) {
        int index = trouverPatient(id);
        printf(C_B_CYAN "\n\n    [ V ] Connexion reussie. Bienvenue M/Mme %s.\n" C_RESET, patients[index].nom);
        Sleep(1000);
        return id;
    } else {
        printf(C_B_CYAN "\n\n    [ X ] Identifiants incorrects.\n" C_RESET);
        pauseScreen();
        return -1;
    }
}

// ==================== GESTION PROFIL ====================

void afficherPatient(int index) {
    Patient p = patients[index];
    printf("\n========================================\n");
    printf(" ID: %d\n", p.id_patient);
    printf(" Nom: %s %s\n", p.nom, p.prenom);
    printf(" Email: %s\n", p.email);
    printf(" Date de naissance: %s\n", p.date_naissance);
    printf(" Sexe: %s\n", p.sexe);
    printf(" Telephone: %s\n", p.telephone);
    printf("========================================\n");
}

void afficherMonProfil(int id_connecte) {
    int index = trouverPatient(id_connecte);
    if (index == -1) return;

    Patient p = patients[index];
    afficherEnteteElegante("M O N   P R O F I L   P E R S O N N E L");
    
    printf("\n" C_GRAY "    INFORMATIONS DE DOSSIER :\n\n" C_RESET);
    
    printf(C_WHITE "    " SYMB_POINT " IDENTIFIANT UNIQUE : " C_B_CYAN "#%d\n", p.id_patient);
    printf(C_WHITE "    " SYMB_POINT " NOM COMPLET        : " C_B_WHITE "%s %s\n", p.nom, p.prenom);
    printf(C_WHITE "    " SYMB_POINT " CIN               : " C_B_WHITE "%s\n", p.cin);
    printf(C_WHITE "    " SYMB_POINT " DATE DE NAISSANCE  : " C_B_WHITE "%s\n", p.date_naissance);
    printf(C_WHITE "    " SYMB_POINT " SEXE               : " C_B_WHITE "%s\n", p.sexe);
    
    printf("\n" C_GRAY "    COORDONNEES DE CONTACT :\n\n" C_RESET);
    printf(C_WHITE "    " SYMB_POINT " ADRESSE E-MAIL     : " C_B_WHITE "%s\n", p.email);
    printf(C_WHITE "    " SYMB_POINT " TELEPHONE          : " C_B_WHITE "%s\n", p.telephone);
    
    printf("\n" C_CYAN "    ============================================================\n" C_RESET);
    printf(C_GRAY "    [ Appuyez sur une touche pour revenir ]" C_RESET);
    _getch(); 
}

void modifierMonProfil(int id_connecte) {
    int index = trouverPatient(id_connecte);
    if (index == -1) return;
    
    char temp[100];
    int modification_faite = 0;

    afficherEnteteElegante("M O D I F I C A T I O N   P R O F I L");
    printf(C_GRAY "    Laissez vide et appuyez sur Entree pour ne pas modifier.\n\n" C_RESET);

    printf(C_WHITE "    " SYMB_POINT " TELEPHONE ACTUEL : " C_B_WHITE "%s\n" C_RESET, patients[index].telephone);
    promptElegante("NOUVEAU NUMERO");
    fflush(stdin); 
    fgets(temp, sizeof(temp), stdin);
    temp[strcspn(temp, "\n")] = 0;
    
    if (strlen(temp) > 0) {
        if (estTelephoneValide(temp)) {
            strcpy(patients[index].telephone, temp);
            modification_faite = 1;
        } else {
            printf(C_B_CYAN "    [ ! ] Format invalide. Modification ignoree.\n" C_RESET);
        }
    }

    // --- MODIFICATION EMAIL ---
    printf("\n" C_WHITE "    " SYMB_POINT " EMAIL ACTUEL     : " C_B_WHITE "%s\n" C_RESET, patients[index].email);
    promptElegante("NOUVEL EMAIL");
    fgets(temp, sizeof(temp), stdin);
    temp[strcspn(temp, "\n")] = 0;

    if (strlen(temp) > 0) {
        if (estEmailValide(temp)) {
            strcpy(patients[index].email, temp);
            modification_faite = 1;
        } else {
            printf(C_B_CYAN "    [ ! ] Format e-mail incorrect. Ignore.\n" C_RESET);
        }
    }

    // --- MODIFICATION MOT DE PASSE ---
    printf("\n" C_GRAY "    SECURITE :\n" C_RESET);
    promptElegante("CHANGER MOT DE PASSE (O/N)");
    char rep;
    scanf(" %c", &rep);
    if (rep == 'O' || rep == 'o') {
        promptElegante("NOUVEAU MOT DE PASSE");
        scanf("%s", temp);
        if (strlen(temp) >= 4) {
            strcpy(patients[index].mot_de_passe, temp);
            modification_faite = 1;
        } else {
            printf(C_B_CYAN "    [ ! ] Trop court (min 4 car.). Annule.\n" C_RESET);
        }
    }

    // --- SAUVEGARDE ---
    if (modification_faite) {
        sauvegarderPatients();
        messageSucces("Vos informations ont ete mises a jour.");
    } else {
        printf(C_GRAY "\n    Aucun changement effectue.\n" C_RESET);
        Sleep(1000);
    }
}

// ==================== GESTION RENDEZ-VOUS ====================

void obtenirDateActuelle(char *date) {
    time_t t = time(NULL);
    struct tm tm = *localtime(&t);
    sprintf(date, "%02d/%02d/%04d", tm.tm_mday, tm.tm_mon + 1, tm.tm_year + 1900);
}

void sauvegarderDemandeRDV(DemandeRDV demande) {
    FILE *f = fopen(FICHIER_DEMANDES_RDV, "a"); 
    
    if (f == NULL) {
        printf("\n   [ERREUR CRITIQUE] Impossible d'ouvrir ou creer le fichier '%s'.\n", FICHIER_DEMANDES_RDV);
        printf("   Verifiez les permissions du dossier.\n");
        return;
    }
    
    int retour = fprintf(f, "%d;%d;%s;%s;%s;%s;%s;%s;%s\n",
            demande.id_demande,
            demande.id_patient,
            demande.nom_patient,
            demande.prenom_patient,
            demande.date_souhaitee,
            demande.heure_souhaitee,
            demande.motif,
            demande.statut,
            demande.date_demande);
            
    if (retour < 0) {
        printf("\n   [ERREUR] Echec de l'ecriture dans le fichier.\n");
    } else {
        fflush(f); 
    }
    
    fclose(f);
}

int genererIDDemande() {
    FILE *f = fopen(FICHIER_DEMANDES_RDV, "r");
    int max_id = 0;
    char ligne[1024]; 

    if (f == NULL) {
        return 1; 
    }

    // On parcourt le fichier ligne par ligne
    while (fgets(ligne, sizeof(ligne), f)) {
        // atoi(ligne) va lire le nombre au début de la ligne jusqu'au premier ';'
        int id_actuel = atoi(ligne);
        
        if (id_actuel > max_id) {
            max_id = id_actuel;
        }
    }

    fclose(f);
    return max_id + 1;
}

void demanderRendezVous(int id_patient) {
    int index = trouverPatient(id_patient);
    DemandeRDV demande;
    
    afficherEnteteElegante("P R E N D R E   R E N D E Z - V O U S");
    printf(C_GRAY "    Veuillez remplir le formulaire de consultation :\n\n" C_RESET);

    demande.id_demande = genererIDDemande();
    demande.id_patient = id_patient;
    strcpy(demande.nom_patient, patients[index].nom);
    strcpy(demande.prenom_patient, patients[index].prenom);

    do {
        promptElegante("DATE SOUHAITEE (AAAA-MM-JJ)");
        scanf("%s", demande.date_souhaitee);
        if (!estDateValide(demande.date_souhaitee)) {
            printf(C_B_CYAN "    [ ! ] Format ou date incorrect.\n" C_RESET);
        } else if (verifierSiDatePassee(demande.date_souhaitee)) {
            int a, m, j; sscanf(demande.date_souhaitee, "%d-%d-%d", &a, &m, &j);
            time_t t = time(NULL); struct tm *n = localtime(&t);
            if (a < (n->tm_year+1900) || (a==(n->tm_year+1900) && m<(n->tm_mon+1)) || (a==(n->tm_year+1900) && m==(n->tm_mon+1) && j<n->tm_mday)) {
                 printf(C_B_CYAN "    [ ! ] Impossible de choisir une date passee.\n" C_RESET);
            } else break;
        } else break;
    } while (1);

    do {
        promptElegante("HEURE SOUHAITEE (HH:MM)");
        scanf("%s", demande.heure_souhaitee);

        if (!estHeureValide(demande.heure_souhaitee)) {
            printf(C_B_CYAN "    [ ! ] Heure invalide ou hors creneau (08:00-18:00).\n" C_RESET);
        } else if (!verifierHeureFuture(demande.date_souhaitee, demande.heure_souhaitee)) {
            printf(C_B_CYAN "    [ ! ] Cette heure est deja passee pour aujourd'hui.\n" C_RESET);
        } else {
            break; // Heure validée
        }
    } while (1);
    
    while(getchar() != '\n'); // Nettoyer le buffer avant le motif (si espace)
    promptElegante("MOTIF DE CONSULTATION");
    fgets(demande.motif, 100, stdin);
    demande.motif[strcspn(demande.motif, "\n")] = 0;

    strcpy(demande.statut, "en attente");
    obtenirDateActuelle(demande.date_demande);

    sauvegarderDemandeRDV(demande);

    printf("\n" C_B_CYAN "    [ V ] Demande envoyee avec succes au secretariat.\n" C_RESET);
    printf(C_GRAY "    Statut actuel : " C_WHITE "En attente de validation.\n" C_RESET);
    Sleep(1500);
}

void afficherMesDemandesRDV(int id_patient) {
    FILE *f = fopen(FICHIER_DEMANDES_RDV, "r");
    afficherEnteteElegante("S U I V I   D E S   D E M A N D E S");
    
    if (!f) {
        printf(C_GRAY "\n    Aucun historique de demande trouve.\n" C_RESET);
        _getch();
        return;
    }

    printf(C_GRAY "    %-5s  %-12s  %-8s  %-15s\n", "ID", "DATE", "HEURE", "STATUT");
    printf(C_CYAN "    ------------------------------------------------------------\n" C_RESET);

    DemandeRDV d;
    int trouve = 0;
    char ligne[512];

    while (fgets(ligne, sizeof(ligne), f)) {
        sscanf(ligne, "%d;%d;%49[^;];%49[^;];%10[^;];%5[^;];%99[^;];%19[^;];%10s",
               &d.id_demande, &d.id_patient, d.nom_patient, d.prenom_patient,
               d.date_souhaitee, d.heure_souhaitee, d.motif, d.statut, d.date_demande);
        
        if (d.id_patient == id_patient) {
            trouve = 1;
            // Couleur différente selon le statut
            char *color = C_WHITE;
            if (strstr(d.statut, "confirme")) color = C_B_CYAN;
            if (strstr(d.statut, "attente")) color = C_GRAY;

            printf(C_WHITE "    %-5d  %-12s  %-8s  " , d.id_demande, d.date_souhaitee, d.heure_souhaitee);
            printf("%s%-15s" C_RESET "\n", color, d.statut);
        }
    }
    
    if (!trouve) printf(C_GRAY "\n    Vous n'avez pas encore de demandes enregistrees.\n" C_RESET);
    
    printf(C_CYAN "    ============================================================\n" C_RESET);
    fclose(f);
    printf(C_GRAY "    [ Appuyez sur une touche pour revenir ]" C_RESET);
    _getch();
}

void afficherMesNotifications(int idConnecte) {
    // On tente d'ouvrir le fichier des rendez-vous confirmés
    FILE *f = fopen(FICHIER_CONFIRMES, "r");
    
    // Titre élégant
    afficherEnteteElegante("B O I T E   D E   R E C E P T I O N");

    if (f == NULL) {
        printf(C_GRAY "\n    Aucune notification ou message pour le moment.\n" C_RESET);
        printf("\n" C_CYAN "    ============================================================\n" C_RESET);
        _getch(); // Attendre que l'utilisateur lise
        return;
    }

    DemandeRDV d;
    char ligne[512];
    int trouve = 0;

    printf("\n" C_GRAY "    MESSAGES DU CABINET : \n\n" C_RESET);

    // Lecture du fichier des confirmations
    while (fgets(ligne, sizeof(ligne), f) != NULL) {
        ligne[strcspn(ligne, "\n")] = 0; // Nettoyage du saut de ligne

        // Extraction des données (format: id_dem;id_pat;nom;prenom;date;heure;motif;statut;date_demande)
        int ret = sscanf(ligne, "%d;%d;%49[^;];%49[^;];%10[^;];%5[^;];%99[^;];%19[^;];%10s",
               &d.id_demande, &d.id_patient,
               d.nom_patient, d.prenom_patient,
               d.date_souhaitee, d.heure_souhaitee,
               d.motif, d.statut, d.date_demande);

        // Si c'est le patient connecté
        if (ret >= 2 && d.id_patient == idConnecte) {
            trouve = 1;
            
            // Affichage style "Carte de message"
            printf(C_B_CYAN "    " SYMB_POINT " CONFIRMATION DE RENDEZ-VOUS\n" C_RESET);
            printf(C_WHITE "       Bonjour %s, votre demande de consultation\n", d.prenom_patient);
            printf("       pour le " C_B_WHITE "%s" C_WHITE " a " C_B_WHITE "%s" C_WHITE " a ete VALIDEE.\n", 
                   d.date_souhaitee, d.heure_souhaitee);
            printf(C_GRAY  "       Motif enregistre : %s\n", d.motif);
            printf("       -----------------------------------------------------\n\n" C_RESET);
        }
    }

    fclose(f);

    if (!trouve) {
        printf(C_GRAY "    Votre boite de reception est vide.\n" C_RESET);
        printf(C_GRAY "    (Vos demandes sont peut-etre encore en attente).\n" C_RESET);
    }

    printf("\n" C_CYAN "    ============================================================\n" C_RESET);
    printf(C_GRAY "    [ Appuyez sur une touche pour revenir ]" C_RESET);
    _getch(); // Pause pour bloquer l'écran
}

// ==================== MENU PATIENT CONNECTÉ ====================

void espacePatientConnecte(int id_patient) {
    int choix;
    do {
        afficherEnteteElegante("E S P A C E   P A T I E N T");
        printf(C_GRAY "    Session : M/Mme %s (ID #%d)\n\n" C_RESET, patients[trouverPatient(id_patient)].nom, id_patient);

        afficherLigneOption("1", "VOIR MON PROFIL");
        afficherLigneOption("2", "MODIFIER MON PROFIL");
        afficherLigneOption("3", "PRENDRE RENDEZ-VOUS");
        afficherLigneOption("4", "MES DEMANDES");
        afficherLigneOption("5", "MES NOTIFICATIONS");
        
        printf("\n" C_GRAY "    ------------------------------------------------------------\n" C_RESET);
        afficherLigneOption("0", "DECONNEXION");
        printf(C_GRAY "    ------------------------------------------------------------\n" C_RESET);

        promptElegante("Choix");
        if (scanf("%d", &choix) != 1) { while(getchar() != '\n'); continue; }

        switch (choix) {
            case 1: afficherMonProfil(id_patient); break;
            case 2: modifierMonProfil(id_patient); break;
            case 3: demanderRendezVous(id_patient); break;
            case 4: afficherMesDemandesRDV(id_patient); break;
            case 5: afficherMesNotifications(id_patient); break;
        }
    } while (choix != 0);
}

// ==================== MENU PRINCIPAL PATIENT ====================

void espacePatient() {
    int choix;
    do {
        afficherEnteteElegante("P O R T A I L   P A T I E N T");
        printf(C_GRAY "    Bienvenue. Veuillez vous identifier pour acceder a vos soins.\n\n" C_RESET);

        afficherLigneOption("1", "PREMIERE VISITE (INSCRIPTION)");
        afficherLigneOption("2", "JE SUIS DEJA PATIENT (CONNEXION)");

        printf("\n" C_GRAY "    ------------------------------------------------------------\n" C_RESET);
        afficherLigneOption("0", "RETOUR AU MENU PRINCIPAL");
        printf(C_GRAY "    ------------------------------------------------------------\n" C_RESET);

        promptElegante("Choix");
        if (scanf("%d", &choix) != 1) { 
            while(getchar() != '\n'); 
            continue; 
        }

        switch (choix) {
            case 1: {
                int id = inscrireNouveauPatient();
                if (id != -1) {
                    messageSucces("Inscription enregistree dans la base de donnees.");
                    printf(C_WHITE "\n    Votre identifiant de connexion est : " C_B_CYAN "%d\n" C_RESET, id);
                    printf(C_GRAY "    Veuillez le conserver precieusement.\n" C_RESET);
                    pauseScreen();
                    espacePatientConnecte(id);
                }
                break;
            }
            case 2: {
                int id = loginPatient();
                if (id != -1) {
                    espacePatientConnecte(id);
                }
                break;
            }
        }
    } while (choix != 0);
}


//================== ESPACE SECRETAIRE ==================

// FONCTIONS UTILITAIRES D'AFFICHAGE

void afficherLigneSeparatrice(int longueur, char caractere) {
    for (int i = 0; i < longueur; i++) {
        printf("%c", caractere);
    }
    printf("\n");
}

void afficherTitreCentre(const char* titre, int largeur) {
    int longueur = strlen(titre);
    int espaces = (largeur - longueur) / 2;

    afficherLigneSeparatrice(largeur, '=');
    for (int i = 0; i < espaces; i++) printf(" ");
    printf("%s\n", titre);
    afficherLigneSeparatrice(largeur, '=');
}

void afficherMessageSucces(const char* message) {
    printf("\n");
    afficherLigneSeparatrice(50, '*');
    printf("    %s\n", message);
    afficherLigneSeparatrice(50, '*');
    printf("\n");
}

// LOGIN SECRETAIRE

int loginSecretaire() {
    char login[20], password[20];
    
    afficherEnteteElegante("A U T H E N T I F I C A T I O N   S E C R E T A R I A T");
    printf(C_GRAY "    Acces reserve au personnel administratif.\n\n" C_RESET);

    printf(C_WHITE "    IDENTIFIANT : " C_B_CYAN);
    scanf("%19s", login);

    printf(C_WHITE "    MOT DE PASSE : " C_B_CYAN);
    saisirMotDePasseMasque(password, 20);

    printf(C_GRAY "\n    Verification des acces..." C_RESET);
    Sleep(600);

    if (strcmp(login, LOGIN_SEC) == 0 && strcmp(password, PASS_SEC) == 0) {
        printf(C_B_CYAN "\n\n    [ V ] Connexion reussie - Bienvenue au secretariat!\n" C_RESET);
        Sleep(1000);
        return 1;
    } else {
        printf(C_B_CYAN "\n\n    [ X ] Identifiants incorrects.\n" C_RESET);
        return 0;
    }
}

// GESTION DES PATIENTS

void menuGestionPatients() {
    int choix;
    do {
        afficherEnteteElegante("G E S T I O N   D E S   P A T I E N T S");
        
        afficherLigneOption("1", "REPERTOIRE COMPLET");
        afficherLigneOption("2", "RECHERCHER UN PATIENT");
        afficherLigneOption("3", "SUPPRIMER UN PATIENT");
        
        printf("\n" C_GRAY "    ------------------------------------------------------------\n" CLR_RESET);
        afficherLigneOption("0", "RETOUR AU MENU PRINCIPAL");
        printf(C_GRAY "    ------------------------------------------------------------\n" CLR_RESET);
        
        promptElegante("Choix");
        scanf("%d", &choix);
        while(getchar() != '\n'); 

        switch (choix) {
            case 1: chargerPatients(); afficherTousPatients(); break;
            case 2: chargerPatients(); rechercherPatient(); break;
            case 3: chargerPatients(); supprimerPatient(); break;
        }
    } while (choix != 0);
}

void chargerPatients() {
    FILE *f = fopen(FICHIER_PATIENTS, "r");
    if (!f) {
        nb_patients = 0;
        return;
    }

    nb_patients = 0; 
    char ligne[1024];

    while (fgets(ligne, sizeof(ligne), f) != NULL) {
        if (nb_patients >= MAX_PATIENTS) break;

        Patient p;
        int champs = sscanf(ligne, "%d;%49[^;];%49[^;];%14[^;];%49[^;];%14[^;];%9[^;];%19[^;];%14[^;];%d",
               &p.id_patient, 
               p.nom, 
               p.prenom, 
               p.cin, 
               p.email, 
               p.date_naissance, 
               p.sexe, 
               p.mot_de_passe, 
               p.telephone, 
               &p.actif);

        if (champs >= 9) {
            patients[nb_patients] = p;
            nb_patients++;
        }
    }
    fclose(f);
}

void afficherTousPatients() {
    chargerPatients(); 
    system("cls");
    afficherEnteteElegante("R E P E R T O I R E   P A T I E N T S");
    
    if (nb_patients == 0) {
        printf(C_B_CYAN "    [ ! ] Aucun patient enregistre.\n" C_RESET);
    } else {
        printf(C_B_WHITE "    %-5s  %-20s  %-15s  %-10s\n" C_RESET, "ID", "NOM COMPLET", "TELEPHONE", "SEXE");
        printf(C_CYAN "    ------------------------------------------------------------\n" C_RESET);

        for (int i = 0; i < nb_patients; i++) {
            if (patients[i].actif) {
                printf(C_WHITE "    %-5d  %-20s  %-15s  %-10s\n" C_RESET, 
                       patients[i].id_patient, patients[i].nom, patients[i].telephone, patients[i].sexe);
            }
        }
    }
    pauseSecretaire();
}

void afficherDashboard() {
    afficherEnteteElegante("T A B L E A U   D E   B O R D");
    
    int rdv_attente = 0; 
    
    printf("\n" C_GRAY "    STATISTIQUES GENERALES :\n\n" C_RESET);
    
    printf(C_B_WHITE "    " SYMB_POINT " Patients enregistres : " C_B_CYAN "%d\n", nb_patients);
    printf(C_B_WHITE "    " SYMB_POINT " Demandes en attente   : " C_B_CYAN "%d\n", 5); // Exemple
    printf(C_B_WHITE "    " SYMB_POINT " Chiffre d'affaires    : " C_B_CYAN "En cours...\n\n");
    
    printf(C_CYAN "    ============================================================\n" C_RESET);
    pauseScreen();
}

int compterLignesFichier(const char* nomFichier) {
    FILE *f = fopen(nomFichier, "r");
    if (!f) return 0;
    int count = 0;
    char ligne[512];
    while (fgets(ligne, sizeof(ligne), f)) count++;
    fclose(f);
    return count;
}

void afficherStatistiquesGenerales() {
    system("cls");
    afficherEnteteElegante("T A B L E A U   D E   B O R D   G E N E R A L");

    int totalPatients = 0;
    for(int i=0; i<nb_patients; i++) if(patients[i].actif) totalPatients++;

    int attente = compterLignesFichier(FICHIER_DEMANDES_RDV);
    
    FILE *f = fopen(FICHIER_FACTURES, "r");
    float impayes = 0;
    if(f) {
        char l[512]; float m, p, r;
        while(fgets(l, sizeof(l), f)) {
            if(sscanf(l, "%*[^;];%*[^;];%*[^;];%f;%f;%f", &m, &p, &r) == 3) impayes += r;
        }
        fclose(f);
    }

    printf("\n" C_B_WHITE "    RESUME DE L'ACTIVITE :" C_RESET);
    printf("\n" C_CYAN "    ================================================" C_RESET);
    printf("\n    " SYMB_POINT " PATIENTS ACTIFS      : " C_B_CYAN "%d" C_RESET, totalPatients);
    printf("\n    " SYMB_POINT " RDV EN ATTENTE       : " C_B_YELLOW "%d" C_RESET, attente);
    printf("\n    " SYMB_POINT " TOTAL DES IMPAYES    : " RED "%.2f DH" C_RESET, impayes);
    printf("\n" C_CYAN "    ================================================" C_RESET);
    printf("\n" C_GRAY "    Derniere mise a jour : Aujourd'hui\n" C_RESET);

    pauseSecretaire();
}

void dessinerBarre(int pourcentage, const char* couleur) {
    int largeurMax = 30; // Longueur de la barre en caractères
    int remplissage = (pourcentage * largeurMax) / 100;

    printf(" [");
    printf("%s", couleur);
    for (int i = 0; i < largeurMax; i++) {
        if (i < remplissage) printf("%c", 219); // Caractère bloc plein █
        else printf(" ");
    }
    printf(C_RESET "] %d%%\n", pourcentage);
}
void afficherStatistiquesPatients() {
    chargerPatients(); 
    int total = 0, h = 0, f = 0;

    for (int i = 0; i < nb_patients; i++) {
        if (patients[i].actif) {
            total++;
            if (toupper(patients[i].sexe[0]) == 'M') h++;
            else if (toupper(patients[i].sexe[0]) == 'F') f++;
        }
    }

    system("cls");
    afficherEnteteElegante("V I S U A L I S A T I O N   P A T I E N T S");
    
    if (total > 0) {
        int p_h = (h * 100) / total;
        int p_f = (f * 100) / total;

        printf("\n    REPARTITION PAR SEXE :\n\n");
        
        printf(C_WHITE "    HOMMES   (%d) ", h);
        dessinerBarre(p_h, BOLD_BLUE);
        
        printf(C_WHITE "    FEMMES   (%d) ", f);
        dessinerBarre(p_f, MAGENTA);
        
        printf("\n    " SYMB_POINT " Total patients actifs : %d\n", total);
    } else {
        printf(RED "    Aucune donnee a plotter.\n" C_RESET);
    }
    pauseSecretaire();
}
void afficherStatistiquesFinancieres() {
    FILE *file = fopen(FICHIER_FACTURES, "r");
    float totalFacture = 0, totalPaye = 0;
    char ligne[512];
    Facture fac;

    while (fgets(ligne, sizeof(ligne), file)) {
        if (sscanf(ligne, "%99[^;];%19[^;];%10[^;];%f;%f;%f", 
                   fac.NOM, fac.CIN, fac.date_payement, &fac.montant, &fac.paye, &fac.restant) == 6) {
            totalFacture += fac.montant;
            totalPaye += fac.paye;
        }
    }
    fclose(file);

    system("cls");
    afficherEnteteElegante("A N A L Y S E   F I N A N C I E R E");

    if (totalFacture > 0) {
        int p_paye = (totalPaye * 100) / totalFacture;
        int p_reste = 100 - p_paye;

        printf("\n    ETAT DU RECOUVREMENT (Total: %.2f DH) :\n\n", totalFacture);
        
        printf(C_WHITE "    ENCAISSE  ");
        dessinerBarre(p_paye, GREEN);
        
        printf(C_WHITE "    IMPAYES   ");
        dessinerBarre(p_reste, RED);

        printf("\n    " SYMB_POINT " Somme recuperee : " GREEN "%.2f DH\n" C_RESET, totalPaye);
        printf("    " SYMB_POINT " Somme restante  : " RED "%.2f DH\n" C_RESET, totalFacture - totalPaye);
    }
    pauseSecretaire();
}
void afficherStatistiquesRDV() {
    int att = compterLignesFichier(FICHIER_DEMANDES_RDV);
    int conf = compterLignesFichier(FICHIER_CONFIRMES);
    int ref = compterLignesFichier(FICHIER_REFUS);
    int total = att + conf + ref;

    system("cls");
    afficherEnteteElegante("P L O T   D E S   R E N D E Z - V O U S");

    if (total > 0) {
        printf("\n    STATUTS DES DEMANDES :\n\n");
        
        printf(C_WHITE "    CONFIRMES "); dessinerBarre((conf * 100) / total, CYAN);
        printf(C_WHITE "    EN ATTENTE"); dessinerBarre((att * 100) / total, YELLOW);
        printf(C_WHITE "    REFUSES   "); dessinerBarre((ref * 100) / total, RED);
    }
    pauseSecretaire();
}


// ESPACE SECRETAIRE PRINCIPAL

void espaceSecretaire() {
    int choix;
    if (!loginSecretaire()) return;

    do {
        system("cls");
        afficherEnteteElegante("E S P A C E   S E C R E T A R I A T");
        printf(C_GRAY "    Session : %s | Statut : Connecte\n\n", LOGIN_SEC);

        afficherLigneOption("1", "GESTION DES PATIENTS");
        afficherLigneOption("2", "GESTION DES RDV");
        afficherLigneOption("3", "COMPTABILITE");
        afficherLigneOption("4", "STATISTIQUES");
        printf("\n");
        afficherLigneOption("0", "DECONNEXION");

        printf("\n" C_BOLD C_CYAN "    Choix > " C_RESET);
        if (scanf("%d", &choix) != 1) {
            while(getchar() != '\n'); 
            continue;
        }
        while(getchar() != '\n'); 

        switch (choix) {
            case 1: menuGestionPatients(); break;
            case 2: menuGestionRDV(); break;
            case 3: menuGestionComptabilite(); break;
            case 4: menuGestionStatistiques(); break;
        }
    } while (choix != 0);
}



void rechercherPatient() {
    int id;
    afficherEnteteElegante("R E C H E R C H E   P A T I E N T");
    
    id = lireEntier("\n    Entrez l'ID du patient : ");

    for (int i = 0; i < nb_patients; i++) {
        if (patients[i].id_patient == id && patients[i].actif) {
            printf("\n");
            afficherLigneSeparatrice(60, '=');
            printf(C_B_CYAN "                 PATIENT TROUVE\n" CLR_RESET);
            afficherLigneSeparatrice(60, '=');
            printf("\n");
            printf(C_WHITE "    " SYMB_POINT " ID Patient     : " C_B_CYAN "%d\n" CLR_RESET, patients[i].id_patient);
            printf(C_WHITE "    " SYMB_POINT " Nom complet    : " C_B_WHITE "%s %s\n" CLR_RESET, patients[i].nom, patients[i].prenom);
            printf(C_WHITE "    " SYMB_POINT " Email          : " C_GRAY "%s\n" CLR_RESET, patients[i].email);
            printf(C_WHITE "    " SYMB_POINT " Telephone      : " C_GRAY "%s\n" CLR_RESET, patients[i].telephone);
            printf(C_WHITE "    " SYMB_POINT " Date naissance : " C_GRAY "%s\n" CLR_RESET, patients[i].date_naissance);
            printf(C_WHITE "    " SYMB_POINT " Sexe           : " C_GRAY "%s\n" CLR_RESET, patients[i].sexe);
            printf("\n");
            afficherLigneSeparatrice(60, '=');
            pauseScreen();
            return;
        }
    }
    printf(C_B_CYAN "\n    [ ! ] Aucun patient trouve avec l'ID %d\n" CLR_RESET, id);
    pauseScreen();
}

void supprimerPatient() {
    int id;
    afficherEnteteElegante("S U P P R E S S I O N   P A T I E N T");
    
    id = lireEntier("\n    Entrez l'ID du patient a supprimer : ");
    
    int trouve = 0;
    for (int i = 0; i < nb_patients; i++) {
        if (patients[i].id_patient == id && patients[i].actif == 1) {
            patients[i].actif = 0;
            sauvegarderPatients(); 
            afficherMessageSucces("PATIENT SUPPRIME AVEC SUCCES");
            trouve = 1;
            break;
        }
    }
    
    if (!trouve) {
        printf(C_B_CYAN "\n    [ ! ] Aucun patient trouve avec l'ID %d\n" CLR_RESET, id);
    }
    pauseScreen();
}

// GESTION DES RDV

void menuGestionRDV() {
    int choix;
    do {
        system("cls");
        afficherEnteteElegante("G E S T I O N   D E S   R E N D E Z - V O U S");
        
        afficherLigneOption("1", "TOUTES LES DEMANDES");
        afficherLigneOption("2", "DEMANDES EN ATTENTE");
        afficherLigneOption("3", "CONFIRMER UNE DEMANDE");
        afficherLigneOption("4", "REFUSER UNE DEMANDE");
        
        printf("\n" C_GRAY "    ------------------------------------------------------------\n" CLR_RESET);
        afficherLigneOption("0", "RETOUR");
        printf(C_GRAY "    ------------------------------------------------------------\n" CLR_RESET);
        
        promptElegante("Choix");
        if (scanf("%d", &choix) != 1) {
            while(getchar() != '\n'); 
            continue;
        }
        while(getchar() != '\n');

        switch (choix) {
            case 1: listerToutesDemandes(); break;
            case 2: listerDemandesEnAttente(); break;
            case 3: confirmerDemande(); break;
            case 4: refuserDemande(); break;
        }
    } while (choix != 0);
}

void listerToutesDemandes() {
    FILE *f = fopen(FICHIER_DEMANDES_RDV, "r");
    system("cls");
    afficherEnteteElegante("T O U T E S   L E S   D E M A N D E S");

    if (!f) {
        printf(C_GRAY "    Aucun historique de demande.\n" C_RESET);
        pauseSecretaire();
        return;
    }

    printf(C_B_WHITE "    %-4s  %-18s  %-12s  %-15s\n" C_RESET, "ID", "PATIENT", "DATE RDV", "STATUT");
    printf(C_CYAN "    ------------------------------------------------------------\n" C_RESET);

    DemandeRDV d;
    char ligne[512];
    while (fgets(ligne, sizeof(ligne), f)) {
        if (sscanf(ligne, "%d;%d;%49[^;];%49[^;];%10[^;];%5[^;];%99[^;];%19[^;];%10s",
                   &d.id_demande, &d.id_patient, d.nom_patient, d.prenom_patient,
                   d.date_souhaitee, d.heure_souhaitee, d.motif, d.statut, d.date_demande) >= 8) {
            
            char *color = (strstr(d.statut, "confirme")) ? GREEN : (strstr(d.statut, "refuse") ? RED : C_GRAY);
            printf(C_WHITE "    %-4d  %-18.18s  %-12s  %s%-15s" C_RESET "\n", 
                   d.id_demande, d.nom_patient, d.date_souhaitee, color, d.statut);
        }
    }
    fclose(f);
    pauseSecretaire();
}

void deplacerDemande(int id_demande, char nouveauFichier[], char nouveauStatut[]) {
    FILE *f = fopen(FICHIER_DEMANDES_RDV, "r");
    if (!f) return;

    FILE *temp = fopen("temp.txt", "w");
    FILE *dest = fopen(nouveauFichier, "a");
    
    char ligne[512];
    int trouve = 0;

    while (fgets(ligne, sizeof(ligne), f)) {
        DemandeRDV d;
        sscanf(ligne, "%d;%d;%49[^;];%49[^;];%10[^;];%5[^;];%99[^;];%19[^;];%10s",
               &d.id_demande, &d.id_patient, d.nom_patient, d.prenom_patient,
               d.date_souhaitee, d.heure_souhaitee, d.motif, d.statut, d.date_demande);

        if (d.id_demande == id_demande) {
            trouve = 1;
            fprintf(dest, "%d;%d;%s;%s;%s;%s;%s;%s;%s\n",
                    d.id_demande, d.id_patient, d.nom_patient, d.prenom_patient,
                    d.date_souhaitee, d.heure_souhaitee, d.motif, nouveauStatut, d.date_demande);
        } else {
            fprintf(temp, "%s", ligne);
        }
    }

    fclose(f); fclose(temp); fclose(dest);

    if (trouve) {
        remove(FICHIER_DEMANDES_RDV);
        rename("temp.txt", FICHIER_DEMANDES_RDV);
        printf(GREEN "\n    [ V ] Operation reussie.\n" C_RESET);
    } else {
        remove("temp.txt");
        printf(RED "\n    [ X ] ID #%d non trouve.\n" C_RESET, id_demande);
    }
    pauseSecretaire();
}

void listerDemandesEnAttente() {
    FILE *f = fopen(FICHIER_DEMANDES_RDV, "r");
    
    system("cls");
    afficherEnteteElegante("D E M A N D E S   E N   A T T E N T E");
    
    if (!f) {
        printf(C_B_CYAN "\n    [ ! ] Aucun fichier de demandes trouve.\n" CLR_RESET);
        printf(C_GRAY "    [ Appuyez sur une touche pour revenir ]" C_RESET);
        _getch();
        return;
    }

    printf(C_B_WHITE "    %-4s  %-20s  %-12s  %-25s\n" CLR_RESET, 
           "ID", "PATIENT", "DATE RDV", "MOTIF");
    printf(C_CYAN "    ----------------------------------------------------------------------\n" CLR_RESET);

    DemandeRDV d;
    char ligne[512];
    int count = 0;

    // 2. Lecture robuste ligne par ligne
    while (fgets(ligne, sizeof(ligne), f) != NULL) {
        // Nettoyage des caractères invisibles en fin de ligne
        ligne[strcspn(ligne, "\r\n")] = 0;

        // sscanf avec format correspondant exactement au fichier
        int ret = sscanf(ligne, "%d;%d;%49[^;];%49[^;];%10[^;];%5[^;];%99[^;];%19[^;];%10s",
               &d.id_demande, &d.id_patient, d.nom_patient, d.prenom_patient,
               d.date_souhaitee, d.heure_souhaitee, d.motif, d.statut, d.date_demande);

        // On vérifie si le statut est "en attente"
        if (ret >= 8 && strstr(d.statut, "attente") != NULL) {
            printf(C_WHITE "    %-4d  %-20.20s  %-12s  %-25.25s\n" CLR_RESET, 
                   d.id_demande, d.nom_patient, d.date_souhaitee, d.motif);
            count++;
        }
    }
    
    fclose(f);

    if (count == 0) {
        printf(C_GRAY "\n    Aucune demande en attente de traitement.\n" C_RESET);
    } else {
        printf(C_CYAN "    ----------------------------------------------------------------------\n" C_RESET);
        printf(C_B_CYAN "    Total : %d demande(s) a traiter.\n" C_RESET, count);
    }

    printf(C_GRAY "\n    [ Appuyez sur une touche pour revenir au menu ]" C_RESET);
    fflush(stdin); 
    _getch(); 
}

void confirmerDemande() {
    afficherEnteteElegante("C O N F I R M A T I O N   D E   R D V");
    int id = lireEntier("\n    Entrez l'ID de la demande a confirmer : ");
    deplacerDemande(id, FICHIER_CONFIRMES, "confirme");
    
    printf(GREEN "\n    [ V ] La demande a ete traitee avec succes." C_RESET);
    maPause(); 
}

void refuserDemande() {
    afficherEnteteElegante("R E F U S   D E   R D V");
    int id = lireEntier("\n    Entrez l'ID de la demande a refuser : ");
    deplacerDemande(id, FICHIER_REFUS, "refuse");
    
    printf(YELLOW "\n    [ ! ] La demande a ete deplacee vers les refus." C_RESET);
    maPause();
}

// GESTION DE COMPTABILITE

void menuGestionComptabilite() {
    int choix;
    do {
        afficherEnteteElegante("G E S T I O N   C O M P T A B I L I T E");
        
        afficherLigneOption("1", "NOUVELLE FACTURE");
        afficherLigneOption("2", "LISTE DES FACTURES");
        afficherLigneOption("3", "RECHERCHER UNE FACTURE");
        afficherLigneOption("4", "ENREGISTRER UN PAIEMENT");
        afficherLigneOption("5", "FACTURES IMPAYEES");
        
        printf("\n" C_GRAY "    ------------------------------------------------------------\n" CLR_RESET);
        afficherLigneOption("0", "RETOUR");
        printf(C_GRAY "    ------------------------------------------------------------\n" CLR_RESET);
        
        promptElegante("Choix");
        if (scanf("%d", &choix) != 1) { 
            while(getchar() != '\n'); 
            continue; 
        }
        switch (choix) {
            case 1: ajouterFacture(); break;
            case 2: afficherToutesFactures(); break;
            case 3: afficherUneFacture(); break;
            case 4: enregistrerPaiement(); break;
            case 5: afficherFacturesImpayees(); break;
        }
    } while (choix != 0);
}
void ajouterFacture() {
    int idRecherche;
    Facture f;
    FILE *file = fopen(FICHIER_FACTURES, "a");

    system("cls");
    afficherEnteteElegante("N O U V E L L E   F A C T U R E");

    // 1. On demande l'ID du patient pour récupérer ses infos
    printf(C_WHITE "    IDENTIFIANT (ID) DU PATIENT : " C_B_CYAN);
    if (scanf("%d", &idRecherche) != 1) {
        while(getchar() != '\n'); return;
    }

    // 2. On cherche le patient dans le tableau global (déjà chargé par chargerPatients)
    int index = -1;
    for (int i = 0; i < nb_patients; i++) {
        if (patients[i].id_patient == idRecherche && patients[i].actif) {
            index = i;
            break;
        }
    }

    if (index == -1) {
        printf(RED "\n    [ ! ] Patient #%d introuvable. Verifiez l'ID.\n" C_RESET, idRecherche);
        pauseSecretaire();
        return;
    }

    // 3. Auto-remplissage des informations
    strcpy(f.NOM, patients[index].nom);
    strcpy(f.CIN, patients[index].cin); 
    
    printf(C_GRAY "    Patient detecte : " C_B_WHITE "%s %s (CIN: %s)\n\n" C_RESET, 
           patients[index].nom, patients[index].prenom, f.CIN);

    // 4. Saisie des détails financiers
    printf(C_WHITE "    DATE (JJ/MM/AAAA) : " C_B_CYAN); scanf("%s", f.date_payement);
    printf(C_WHITE "    MONTANT TOTAL (DH) : " C_B_CYAN); scanf("%f", &f.montant);
    printf(C_WHITE "    MONTANT PAYE (DH)  : " C_B_CYAN); scanf("%f", &f.paye);

    f.restant = f.montant - f.paye;

    // 5. Sauvegarde
    if (file) {
        fprintf(file, "%s;%s;%s;%.2f;%.2f;%.2f\n", f.NOM, f.CIN, f.date_payement, f.montant, f.paye, f.restant);
        fclose(file);
        printf(GREEN "\n    [ V ] Facture enregistree avec succes pour %s.\n" C_RESET, f.NOM);
    }

    while(getchar() != '\n');
    pauseSecretaire();
}
void afficherToutesFactures() {
    FILE *file = fopen(FICHIER_FACTURES, "r");
    Facture f;
    char ligne[512];
    int count = 0;

    system("cls"); 
    afficherEnteteElegante("L I S T E   D E S   F A C T U R E S");

    if (!file) {
        printf(C_B_CYAN "\n    [ ! ] Aucune facture trouvee (Fichier absent).\n" CLR_RESET);
        printf(C_GRAY "    [ Appuyez sur une touche pour revenir ]" C_RESET);
        _getch();
        return;
    }

    // En-tête du tableau
    printf(C_B_WHITE "    %-20s  %-12s  %-10s  %-10s  %-10s\n" CLR_RESET,
           "NOM PATIENT", "CIN", "MONTANT", "PAYE", "RESTE");
    printf(C_CYAN "    ----------------------------------------------------------------------\n" CLR_RESET);

    // Lecture ligne par ligne pour éviter les bugs de format
    while (fgets(ligne, sizeof(ligne), file) != NULL) {
        // Format : NOM;CIN;DATE;MONTANT;PAYE;RESTANT
        int res = sscanf(ligne, "%99[^;];%19[^;];%10[^;];%f;%f;%f",
                        f.NOM, f.CIN, f.date_payement, &f.montant, &f.paye, &f.restant);

        if (res == 6) {
            printf(C_WHITE "    %-20.20s  %-12s  %8.2f   %8.2f   " C_RESET, 
                   f.NOM, f.CIN, f.montant, f.paye);
            
            if (f.restant > 0) printf(C_B_CYAN "%8.2f\n" C_RESET, f.restant);
            else printf(C_GRAY "%8.2f\n" C_RESET, f.restant);
            
            count++;
        }
    }

    fclose(file);

    if (count == 0) {
        printf(C_GRAY "    Le registre des factures est vide.\n" C_RESET);
    } else {
        printf(C_CYAN "    ----------------------------------------------------------------------\n" C_RESET);
        printf(C_GRAY "    Total : %d facture(s) enregistree(s).\n" C_RESET, count);
    }

    printf(C_B_WHITE "\n    >> Appuyez sur une TOUCHE pour revenir au menu..." C_RESET);
    fflush(stdin); 
    _getch(); 
}
void afficherUneFacture() {
    char recherche[20];
    FILE *file = fopen(FICHIER_FACTURES, "r");
    Facture f;
    char ligne[512];
    int trouve = 0;

    system("cls");
    afficherEnteteElegante("R E C H E R C H E   F A C T U R E");

    if (!file) {
        printf(RED "\n    [ ! ] Fichier des factures absent.\n" C_RESET);
        _getch(); return;
    }

    printf("\n    Entrez le CIN ou le NOM du patient : " C_B_CYAN);
    scanf("%s", recherche);
    while(getchar() != '\n');

    while (fgets(ligne, sizeof(ligne), file)) {
        if (sscanf(ligne, "%99[^;];%19[^;];%10[^;];%f;%f;%f",
                   f.NOM, f.CIN, f.date_payement, &f.montant, &f.paye, &f.restant) == 6) {
            
            // On cherche si le texte saisi correspond au CIN ou au NOM
            if (strcmp(f.CIN, recherche) == 0 || strstr(f.NOM, recherche) != NULL) {
                trouve = 1;
                printf("\n" C_CYAN "    --------------------------------------------" C_RESET);
                printf("\n    " SYMB_POINT " PATIENT : %s (CIN: %s)", f.NOM, f.CIN);
                printf("\n    " SYMB_POINT " DATE    : %s", f.date_payement);
                printf("\n    " SYMB_POINT " TOTAL   : %.2f DH", f.montant);
                printf("\n    " SYMB_POINT " PAYE    : %.2f DH", f.paye);
                printf("\n    " SYMB_POINT " RESTE   : " RED "%.2f DH" C_RESET, f.restant);
                printf("\n" C_CYAN "    --------------------------------------------\n" C_RESET);
            }
        }
    }
    fclose(file);

    if (!trouve) printf(RED "\n    [ X ] Aucune facture trouvee pour : %s\n" C_RESET, recherche);

    printf(C_GRAY "\n    [ Appuyez sur une touche pour revenir ]" C_RESET);
    _getch();
}

void enregistrerPaiement() {
    char cinCherche[20];
    float montantSaisi;
    FILE *file = fopen(FICHIER_FACTURES, "r");
    FILE *temp = fopen("temp_factures.txt", "w");
    Facture f;
    char ligne[512];
    int trouve = 0;

    system("cls");
    afficherEnteteElegante("P A I E M E N T   D' U N E   F A C T U R E");

    if (!file || !temp) {
        printf(RED "\n    [ ! ] Erreur d'ouverture des fichiers.\n" C_RESET);
        if(file) fclose(file);
        if(temp) fclose(temp);
        _getch(); return;
    }

    printf("\n    Entrez le CIN du patient : " C_B_CYAN);
    scanf("%s", cinCherche);
    printf(C_WHITE "    Montant du versement (DH) : " C_B_CYAN);
    scanf("%f", &montantSaisi);
    while(getchar() != '\n'); 

    while (fgets(ligne, sizeof(ligne), file)) {
        if (sscanf(ligne, "%99[^;];%19[^;];%10[^;];%f;%f;%f",
                   f.NOM, f.CIN, f.date_payement, &f.montant, &f.paye, &f.restant) == 6) {
            
            if (strcmp(f.CIN, cinCherche) == 0) {
                trouve = 1;
                f.paye += montantSaisi;
                f.restant = f.montant - f.paye;

                if (f.restant < 0) f.restant = 0; 

                printf(GREEN "\n    [ V ] Paiement enregistre pour %s.\n" C_RESET, f.NOM);
                printf(C_GRAY "    Nouveau Reste : " C_B_CYAN "%.2f DH\n" C_RESET, f.restant);
            }
            fprintf(temp, "%s;%s;%s;%.2f;%.2f;%.2f\n",
                    f.NOM, f.CIN, f.date_payement, f.montant, f.paye, f.restant);
        }
    }

    fclose(file);
    fclose(temp);

    remove(FICHIER_FACTURES);
    rename("temp_factures.txt", FICHIER_FACTURES);

    if (!trouve) {
        printf(RED "\n    [ X ] Aucune facture trouvee pour le CIN : %s\n" C_RESET, cinCherche);
    }

    pauseSecretaire();
}

void afficherFacturesImpayees() {
    FILE *file = fopen(FICHIER_FACTURES, "r");
    Facture f;
    char ligne[512];
    int count = 0;

    system("cls");
    afficherEnteteElegante("F A C T U R E S   I M P A Y E E S");

    if (!file) {
        printf(C_GRAY "\n    Aucun registre de facturation trouve.\n" C_RESET);
        _getch(); return;
    }

    printf(C_B_WHITE "    %-20s  %-12s  %-10s  %-10s\n" CLR_RESET,
           "NOM PATIENT", "CIN", "TOTAL", "RESTE DU");
    printf(C_CYAN "    ------------------------------------------------------------\n" CLR_RESET);

    while (fgets(ligne, sizeof(ligne), file)) {
        if (sscanf(ligne, "%99[^;];%19[^;];%10[^;];%f;%f;%f",
                   f.NOM, f.CIN, f.date_payement, &f.montant, &f.paye, &f.restant) == 6) {
            
            if (f.restant > 0.01) { 
                printf(C_WHITE "    %-20.20s  %-12s  %8.2f  " C_B_CYAN "%8.2f DH\n" CLR_RESET, 
                       f.NOM, f.CIN, f.montant, f.restant);
                count++;
            }
        }
    }
    fclose(file);

    if (count == 0) {
        printf(GREEN "\n    [ V ] Bravo ! Toutes les factures sont reglees.\n" C_RESET);
    } else {
        printf(C_CYAN "    ------------------------------------------------------------\n" CLR_RESET);
        printf(C_GRAY "    Total : %d dossier(s) en attente de paiement.\n" C_RESET, count);
    }

    pauseSecretaire();
}

// GESTION DES STATISTIQUES

void menuGestionStatistiques() {
    int choix;
    do {
        afficherEnteteElegante("T A B L E A U   D E   B O R D");
        
        afficherLigneOption("1", "STATISTIQUES PATIENTS");
        afficherLigneOption("2", "STATISTIQUES RENDEZ-VOUS");
        afficherLigneOption("3", "STATISTIQUES FINANCIERES");
        afficherLigneOption("4", "VUE D'ENSEMBLE GENERALE");
        
        printf("\n" C_GRAY "    ------------------------------------------------------------\n" CLR_RESET);
        afficherLigneOption("0", "RETOUR");
        printf(C_GRAY "    ------------------------------------------------------------\n" CLR_RESET);
        
        promptElegante("Choix");
        scanf("%d", &choix);

        switch (choix) {
            case 1: afficherStatistiquesPatients(); break;
            case 2: afficherStatistiquesRDV(); break;
            case 3: afficherStatistiquesFinancieres(); break;
            case 4: afficherStatistiquesGenerales(); break;
        }
    } while (choix != 0);
}

/*void afficherStatistiquesPatients() {
    chargerPatients(); 

    int totalActifs = 0;
    int hommes = 0;
    int femmes = 0;

    system("cls");
    afficherEnteteElegante("S T A T I S T I Q U E S   P A T I E N T S");

    if (nb_patients == 0) {
        printf(RED "\n    [ ! ] Erreur : Aucun patient n'a pu être chargé.\n" C_RESET);
        printf(C_GRAY "    Vérifiez que le fichier 'patients.txt' n'est pas vide.\n" C_RESET);
        pauseSecretaire();
        return;
    }

    for (int i = 0; i < nb_patients; i++) {
        if (patients[i].actif == 1) {
            totalActifs++;
            
            // On verifie la première lettre du sexe (M ou F)
            char s = toupper(patients[i].sexe[0]);
            if (s == 'M') {
                hommes++;
            } else if (s == 'F') {
                femmes++;
            }
        }
    }

    // 3. Affichage des résultats
    printf("\n" C_B_WHITE "    ANALYSE DE LA BASE DE DONNEES :" C_RESET);
    printf("\n" C_CYAN "    ------------------------------------------------" C_RESET);
    printf("\n    " SYMB_POINT " TOTAL PATIENTS ENREGISTRES : " C_B_CYAN "%d" C_RESET, nb_patients);
    printf("\n    " SYMB_POINT " TOTAL PATIENTS ACTIFS      : " C_B_CYAN "%d" C_RESET, totalActifs);
    printf("\n" C_CYAN "    ------------------------------------------------" C_RESET);

    if (totalActifs > 0) {
        float pourcHommes = (hommes * 100.0) / totalActifs;
        float pourcFemmes = (femmes * 100.0) / totalActifs;

        printf("\n    " SYMB_POINT " HOMMES (M) : " C_WHITE "%d " C_GRAY "(%.1f%%)" C_RESET, hommes, pourcHommes);
        printf("\n    " SYMB_POINT " FEMMES (F) : " C_WHITE "%d " C_GRAY "(%.1f%%)" C_RESET, femmes, pourcFemmes);
    } else {
        printf(RED "\n    Aucun patient actif pour le calcul des pourcentages.\n" C_RESET);
    }

    printf("\n" C_CYAN "    ------------------------------------------------\n" C_RESET);

    pauseSecretaire();
}*/


//====================== ESPACE MEDECIN ======================//

int medecinConnecteId = -1;

// ==================== STRUCTURES ====================

// Structure Heure
typedef struct {
    int heure;
    int minute;
} Heure;

// Structure Medecin
typedef struct {
    int id;
    char nom[50];
    char prenom[50];
    char specialite[100];
    char telephone[15];
    char email[100];
    char motDePasse[50];
    int actif;
} Medecin;

// Structure DossierMedical
typedef struct {
    int idPatient;
    char groupeSanguin[5];
    char antecedents[500];
    char allergies[200];
    char maladiesChroniques[300];
    char notesMedicales[1000];
    Date dateCreation;
} DossierMedical;

// Structure Consultation
typedef struct {
    int id;
    int idPatient;
    char nomPatient[50];
    char prenomPatient[50];
    Date dateConsultation;
    Heure heureConsultation;
    char motif[200];
    char diagnostic[300];
    char traitement[300];
    float tarif;
} Consultation;

// ==================== VARIABLES GLOBALES ====================

Medecin medecinPrincipal = {
    1, "Alami", "Ahmed", "Generaliste",
    "0612345678", "dr.alami@gmail.com", "H12345", 1
};

// ==================== IMPLEMENTATION DES FONCTIONS ====================

int connexionMedecin();
void EspaceMedecin();
void saisirMotDePasseMasque(char *motDePasse, int taille);

void saisirMotDePasseMasque(char *motDePasse, int taille) {
    int i = 0;
    char ch;
    while (i < taille - 1) {
        ch = _getch(); // Lit une touche sans l'afficher
        if (ch == 13) { // 13 est le code pour "Entrée"
            break;
        } else if (ch == 8) { // 8 est "Retour arrière"
            if (i > 0) {
                i--;
                printf("\b \b"); // Efface l'astérisque à l'écran
            }
        } else {
            motDePasse[i++] = ch;
            printf("*");
        }
    }
    motDePasse[i] = '\0'; 
}

int connexionMedecin() {
    char motDePasseSaisi[50];
    int idSaisi;
    FILE *f;

    // --- ÉTAPE 1 : RECHARGER LES DONNÉES DEPUIS LE FICHIER ---
    f = fopen("medecin.txt","r");
    if (f != NULL) {
        fscanf(f, "%d %s %s %s %s %s %s %d", 
               &medecinPrincipal.id, medecinPrincipal.nom, 
               medecinPrincipal.prenom, medecinPrincipal.specialite, 
               medecinPrincipal.telephone, medecinPrincipal.email, 
               medecinPrincipal.motDePasse, &medecinPrincipal.actif);
        fclose(f);
    }

    afficherEnteteElegante("A U T H E N T I F I C A T I O N   M E D I C A L E");
    printf(C_GRAY "    Acces reserve au personnel de sante.\n\n" C_RESET);

    // --- ÉTAPE 2 : SAISIE SÉCURISÉE ---
    printf(C_WHITE "    IDENTIFIANT PRATICIEN   : " C_B_CYAN);
    if (scanf("%d", &idSaisi) != 1) {
        while(getchar() != '\n'); 
        return 0;
    }
    
    while(getchar() != '\n'); 

    printf(C_WHITE "    MOT DE PASSE DE SESSION : " C_B_CYAN);
    saisirMotDePasseMasque(motDePasseSaisi, sizeof(motDePasseSaisi));

    printf(C_GRAY "\n    Verification des droits d'acces..." C_RESET);
    Sleep(800);

    // --- ÉTAPE 3 : COMPARAISON STRICTE ---
    if (idSaisi == medecinPrincipal.id && strcmp(motDePasseSaisi, medecinPrincipal.motDePasse) == 0) {
        medecinConnecteId = medecinPrincipal.id;
        printf(C_B_CYAN "\n\n    [ V ] Acces accorde. Bienvenue Dr. %s.\n" C_RESET, medecinPrincipal.nom);
        Sleep(1000);
        return 1;
    } else {
        printf(C_B_CYAN "\n\n    [ X ] Identifiants invalides.\n" C_RESET);
        printf(C_GRAY "    Veuillez verifier votre ID et votre mot de passe.\n" C_RESET);
        _getch(); 
        return 0;
    }
}

/*void afficherRendezVousConfirmes() {
    FILE *f = fopen(FICHIER_CONFIRMES, "r");
    
    clearScreen();
    afficherEnteteElegante("L I S T E   D E S   R D V   C O N F I R M E S");
    
    if (!f) {
        printf(C_GRAY "\n    Aucun historique de rendez-vous trouve.\n" C_RESET);
        printf(C_CYAN "    ============================================================\n" C_RESET);
        _getch();
        return;
    }

    printf(C_B_WHITE "    %-4s  %-20s  %-12s  %-8s\n", "ID", "PATIENT", "DATE", "HEURE");
    printf(C_CYAN "    ------------------------------------------------------------\n" C_RESET);

    DemandeRDV d;
    char ligne[512];
    int count = 0;

    while (fgets(ligne, sizeof(ligne), f) != NULL) {
        int ret = sscanf(ligne, "%d;%d;%49[^;];%49[^;];%10[^;];%5[^;];%99[^;];%19[^;];%10s",
               &d.id_demande, &d.id_patient,
               d.nom_patient, d.prenom_patient,
               d.date_souhaitee, d.heure_souhaitee,
               d.motif, d.statut, d.date_demande);

        if (ret >= 6) {
            count++;
            printf(C_B_CYAN "    %-4d" C_WHITE "  %-20.20s  " C_B_WHITE "%-12s  " C_CYAN "%-8s\n", 
                   d.id_demande, 
                   d.nom_patient, 
                   d.date_souhaitee, 
                   d.heure_souhaitee);
            
            printf(C_GRAY "          Motif: %-45.45s\n" C_RESET, d.motif);
        }
    }

    if (count == 0) {
        printf(C_GRAY "\n    Le registre des confirmations est actuellement vide.\n" C_RESET);
    }

    printf("\n" C_CYAN "    ============================================================\n" C_RESET);
    printf(C_GRAY "    [ Total: %d RDV | Appuyez sur une touche pour revenir ]", count);
    
    fclose(f);
    _getch(); 
}*/
void afficherRendezVousConfirmes() {
    FILE *f = fopen(FICHIER_CONFIRMES, "r");
    if (!f) {
        printf("\n" C_GRAY "    Aucun rendez-vous confirme pour le moment.\n" C_RESET);
        _getch();
        return;
    }

    // 1. RÉCUPÉRATION DE LA DATE ACTUELLE
    time_t t = time(NULL);
    struct tm *now = localtime(&t);
    int anActuel = now->tm_year + 1900;
    int moisActuel = now->tm_mon + 1;
    int jourActuel = now->tm_mday;

    afficherEnteteElegante("L I S T E   D E S   R D V   C O N F I R M E S");
    
    // En-tête du tableau (style de votre capture)
    printf(C_B_WHITE "    %-4s %-20s %-15s %-8s\n", "ID", "PATIENT", "DATE", "HEURE");
    printf(C_CYAN "    ----------------------------------------------------------------\n" C_RESET);

    DemandeRDV d;
    char ligne[1024];
    int count = 0;

    while (fgets(ligne, sizeof(ligne), f)) {
        if (sscanf(ligne, "%d;%d;%49[^;];%49[^;];%10[^;];%5[^;];%99[^;];%19[^;];%10s",
               &d.id_demande, &d.id_patient, d.nom_patient, d.prenom_patient,
               d.date_souhaitee, d.heure_souhaitee, d.motif, d.statut, d.date_demande) == 9) {
            
            // 2. EXTRACTION DE LA DATE DU RDV (Format YYYY-MM-DD)
            int a, m, j;
            sscanf(d.date_souhaitee, "%d-%d-%d", &a, &m, &j);

            // 3. LOGIQUE DE FILTRAGE : On ignore si c'est strictement avant aujourd'hui
            int estPasse = 0;
            if (a < anActuel) estPasse = 1;
            else if (a == anActuel && m < moisActuel) estPasse = 1;
            else if (a == anActuel && m == moisActuel && j < jourActuel) estPasse = 1;

            if (!estPasse) {
                // Affichage ligne principale
                printf(C_B_CYAN "    %-4d " C_B_WHITE "%-20s " C_WHITE "%-15s " C_B_CYAN "%-8s\n",
                       d.id_demande, d.nom_patient, d.date_souhaitee, d.heure_souhaitee);
                
                // Affichage du motif sur la ligne suivante (comme sur votre capture)
                printf(C_GRAY "         Motif: %-45s\n" C_RESET, d.motif);
                count++;
            }
        }
    }

    fclose(f);

    printf(C_CYAN "    ================================================================\n" C_RESET);
    printf(C_GRAY "    [ Total: %d RDV | Appuyez sur une touche pour revenir ]\n" C_RESET, count);
    _getch();
}

void afficherMedecin() {
    // --- SYNCHRONISATION AVEC LE FICHIER ---
    FILE *f = fopen("medecin.txt", "r");
    if (f != NULL) {
        fscanf(f, "%d %s %s %s %s %s %s %d\n", 
               &medecinPrincipal.id, medecinPrincipal.nom,
               medecinPrincipal.prenom, medecinPrincipal.specialite,
               medecinPrincipal.telephone, medecinPrincipal.email,
               medecinPrincipal.motDePasse, &medecinPrincipal.actif);
        fclose(f);
    }
    
    system("cls");
    afficherEnteteElegante("P R O F I L   D U   P R A T I C I E N");
    
    printf("\n" C_GRAY "    IDENTITE PROFESSIONNELLE :\n\n" C_RESET);
    
    printf(C_WHITE "    " SYMB_POINT " IDENTIFIANT PRATICIEN : " C_B_CYAN "#%d\n", medecinPrincipal.id);
    printf(C_WHITE "    " SYMB_POINT " NOM COMPLET           : " C_B_WHITE "Dr. %s %s\n", medecinPrincipal.nom, medecinPrincipal.prenom);
    printf(C_WHITE "    " SYMB_POINT " SPECIALISATION        : " C_B_WHITE "%s\n", medecinPrincipal.specialite);
    
    printf("\n" C_GRAY "    COORDONNEES ET CONTACT :\n\n" C_RESET);
    printf(C_WHITE "    " SYMB_POINT " NUMERO DE TELEPHONE   : " C_B_WHITE "%s\n", medecinPrincipal.telephone);
    printf(C_WHITE "    " SYMB_POINT " ADRESSE ELECTRONIQUE  : " C_B_WHITE "%s\n", medecinPrincipal.email);
    
    printf("\n" C_GRAY "    STATUT DU COMPTE :\n\n" C_RESET);
    if (medecinPrincipal.actif) {
        printf(C_WHITE "    " SYMB_POINT " ETAT DU SERVICE       : " GREEN "OPERATIONNEL / ACTIF\n" C_RESET);
    } else {
        printf(C_WHITE "    " SYMB_POINT " ETAT DU SERVICE       : " RED "HORS SERVICE\n" C_RESET);
    }
    
    printf("\n" C_CYAN "    ============================================================\n" C_RESET);
    printf(C_GRAY "    [ Appuyez sur une touche pour revenir ]" C_RESET);
    _getch(); // Bloque l'écran pour permettre la lecture
}
void modifierMedecin() {
    int choix;
    FILE *f;

    do {
        system("cls");
        afficherEnteteElegante("G E S T I O N   D U   P R O F I L   P R A T I C I E N");
        
        printf(C_GRAY "    INFORMATIONS ACTUELLES DU DOSSIER :\n\n" C_RESET);
        printf(C_WHITE "    " SYMB_POINT " NOM          : " C_B_WHITE "%s\n", medecinPrincipal.nom);
        printf(C_WHITE "    " SYMB_POINT " PRENOM       : " C_B_WHITE "%s\n", medecinPrincipal.prenom);
        printf(C_WHITE "    " SYMB_POINT " SPECIALITE   : " C_B_WHITE "%s\n", medecinPrincipal.specialite);
        printf(C_WHITE "    " SYMB_POINT " TELEPHONE    : " C_B_WHITE "%s\n", medecinPrincipal.telephone);
        printf(C_WHITE "    " SYMB_POINT " E-MAIL       : " C_B_WHITE "%s\n", medecinPrincipal.email);
        printf(C_WHITE "    " SYMB_POINT " MOT DE PASSE : " C_B_WHITE "********\n" C_RESET);

        printf("\n" C_GRAY "    SELECTIONNEZ LE CHAMP A MODIFIER :\n" C_RESET);
        afficherLigneOption("1", "Modifier le Nom");
        afficherLigneOption("2", "Modifier le Prenom");
        afficherLigneOption("3", "Modifier la Specialite");
        afficherLigneOption("4", "Modifier le Telephone");
        afficherLigneOption("5", "Modifier l'E-mail");
        afficherLigneOption("6", "Changer le Mot de passe");
        
        printf("\n" C_GRAY "    ------------------------------------------------------------\n" C_RESET);
        afficherLigneOption("0", "RETOUR ET SAUVEGARDER");
        printf(C_GRAY "    ------------------------------------------------------------\n" C_RESET);

        promptElegante("Champ");
        if (scanf("%d", &choix) != 1) { 
            while(getchar() != '\n'); 
            continue; 
        }
        while(getchar() != '\n'); 

        switch(choix) {
            case 1: 
                promptElegante("Nouveau Nom"); 
                scanf("%s", medecinPrincipal.nom); 
                break;
            case 2: 
                promptElegante("Nouveau Prenom"); 
                scanf("%s", medecinPrincipal.prenom); 
                break;
            case 3: 
                promptElegante("Nouvelle Specialite"); 
                scanf("%s", medecinPrincipal.specialite); 
                break;
            case 4: 
                promptElegante("Nouveau Telephone"); 
                scanf("%s", medecinPrincipal.telephone); 
                break;
            case 5: 
                promptElegante("Nouvel Email"); 
                scanf("%s", medecinPrincipal.email); 
                break;
            case 6: 
                promptElegante("Nouveau Mot de passe"); 
                scanf("%s", medecinPrincipal.motDePasse); 
                break;
            case 0: 
                break;
            default:
                printf(RED "\n    [ ! ] Choix non reconnu.\n" C_RESET);
                Sleep(800);
        }

        if (choix >= 1 && choix <= 6) {
            printf(GREEN "\n    [ V ] Modification prise en compte.\n" C_RESET);
            Sleep(800);
        }

    } while(choix != 0);

    // --- SAUVEGARDE FINALE DANS LE FICHIER ---
    f = fopen("medecin.txt", "w");
    if (f == NULL) {
        printf(RED "\n    [ ! ] Erreur critique : Impossible de sauvegarder les modifications.\n" C_RESET);
        _getch();
        return;
    }

    fprintf(f, "%d %s %s %s %s %s %s %d\n", 
            medecinPrincipal.id, medecinPrincipal.nom,
            medecinPrincipal.prenom, medecinPrincipal.specialite,
            medecinPrincipal.telephone, medecinPrincipal.email,
            medecinPrincipal.motDePasse, medecinPrincipal.actif);
    
    fclose(f);

    printf(C_B_CYAN "\n    [ OK ] Profil mis a jour et synchronise avec succes.\n" C_RESET);
    printf(C_GRAY "    Appuyez sur une touche pour revenir..." C_RESET);
    _getch();
}

// ==================== FONCTIONS DOSSIER MEDICAL ====================

int dossierExiste(int idPatient) {
    FILE *f = fopen("dossiers.txt", "r");
    if (f == NULL) return 0;

    DossierMedical d;
    while (fscanf(f, "%d %s %s %s %s %s %d %d %d",
                  &d.idPatient, d.groupeSanguin, d.antecedents,
                  d.allergies, d.maladiesChroniques, d.notesMedicales,
                  &d.dateCreation.jour, &d.dateCreation.mois,
                  &d.dateCreation.annee) != EOF) {
        if (d.idPatient == idPatient) {
            fclose(f);
            return 1;
        }
    }
    fclose(f);
    return 0;
}

void creerDossierMedical() {
    DossierMedical d;
    char dateS[20];
    FILE *f;
    int groupeValide = 0;
    // Liste des groupes sanguins valides
    char *groupesAutorises[] = {"A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"};

    system("cls");
    afficherEnteteElegante("C R E A T I O N   D E   D O S S I E R   M E D I C A L");

    printf(C_GRAY "    Veuillez renseigner les parametres de base du patient.\n\n" C_RESET);
    
    // 1. SAISIE ET VÉRIFICATION DE L'ID
    printf(C_WHITE "    " SYMB_POINT " IDENTIFIANT DU PATIENT : " C_B_CYAN);
    if (scanf("%d", &d.idPatient) != 1) {
        while(getchar() != '\n');
        return;
    }
    while(getchar() != '\n'); 

    if (dossierExiste(d.idPatient)) {
        printf(RED "\n    [ ! ] Un dossier medical existe deja pour l'ID #%d.\n" C_RESET, d.idPatient);
        printf(C_GRAY "    Appuyez sur une touche pour revenir..." C_RESET);
        _getch();
        return;
    }

    printf("\n" C_GRAY "    INFORMATIONS CLINIQUES :\n\n" C_RESET);

    // 2. SAISIE ET VÉRIFICATION DU GROUPE SANGUIN
    do {
        promptElegante("GROUPE SANGUIN (A+/A-/B+/B-/AB+/AB-/O+/O-) ");
        scanf("%s", d.groupeSanguin);
        while(getchar() != '\n');

        // Vérification dans la liste des groupes autorisés
        for (int i = 0; i < 8; i++) {
            if (strcmp(d.groupeSanguin, groupesAutorises[i]) == 0) {
                groupeValide = 1;
                break;
            }
        }

        if (!groupeValide) {
            printf(RED "    [ ! ] Groupe sanguin invalide. Utilisez le format : A+, O-, etc.\n" C_RESET);
        }
    } while (!groupeValide);

    // 3. AUTRES INFORMATIONS
    promptElegante("ANTECEDENTS MEDICAUX ");
    fgets(d.antecedents, sizeof(d.antecedents), stdin);
    d.antecedents[strcspn(d.antecedents, "\n")] = 0;

    promptElegante("ALLERGIES CONNUES ");
    fgets(d.allergies, sizeof(d.allergies), stdin);
    d.allergies[strcspn(d.allergies, "\n")] = 0;

    promptElegante("MALADIES CHRONIQUES ");
    fgets(d.maladiesChroniques, sizeof(d.maladiesChroniques), stdin);
    d.maladiesChroniques[strcspn(d.maladiesChroniques, "\n")] = 0;

    // 4. SAISIE ET VÉRIFICATION DE LA DATE (AAAA-MM-JJ)
    do {
        promptElegante("DATE DE CREATION (AAAA-MM-JJ) ");
        scanf("%s", dateS);

        if (!estDateValide(dateS)) {
            printf(RED "    [ ! ] Format invalide ou date inexistante (AAAA-MM-JJ).\n" C_RESET);
        } else if (!verifierSiDatePassee(dateS)) {
            printf(RED "    [ ! ] La date de creation ne peut pas etre dans le futur.\n" C_RESET);
        } else {
            sscanf(dateS, "%d-%d-%d", &d.dateCreation.annee, &d.dateCreation.mois, &d.dateCreation.jour);
            break; 
        }
    } while (1);

    while(getchar() != '\n');
    strcpy(d.notesMedicales, "Aucune_note_initiale");

    // 5. ENREGISTREMENT
    f = fopen("dossiers.txt", "a");
    if (f == NULL) {
        printf(RED "\n    [ ! ] Erreur d'acces au fichier.\n" C_RESET);
        _getch();
        return;
    }

    fprintf(f, "%d;%s;%s;%s;%s;%s;%04d-%02d-%02d\n",
            d.idPatient, d.groupeSanguin, d.antecedents,
            d.allergies, d.maladiesChroniques, d.notesMedicales,
            d.dateCreation.annee, d.dateCreation.mois, d.dateCreation.jour);

    fclose(f);

    printf(GREEN "\n    [ V ] Dossier medical enregistre avec succes.\n" C_RESET);
    printf(C_GRAY "    Appuyez sur une touche pour continuer..." C_RESET);
    _getch();
}
void afficherDossierMedical() {
    int idRecherche, trouve = 0;
    char ligne[2048]; // Buffer large pour lire les longues descriptions
    DossierMedical d;
    char dateS[20];

    system("cls");
    afficherEnteteElegante("C O N S U L T A T I O N   D E   D O S S I E R");

    printf("\n" C_WHITE "    " SYMB_POINT " ENTRER L'ID DU PATIENT A CONSULTER : " C_B_CYAN);
    if (scanf("%d", &idRecherche) != 1) {
        while(getchar() != '\n'); // Nettoyage en cas d'erreur de saisie
        return;
    }
    while(getchar() != '\n'); // Nettoyage buffer

    FILE *f = fopen("dossiers.txt", "r");
    if (f == NULL) {
        printf(RED "\n    [ ! ] Aucun dossier n'a ete enregistre dans le systemE.\n" C_RESET);
        printf(C_GRAY "    Appuyez sur une touche pour continuer..." C_RESET);
        _getch();
        return;
    }

    // Lecture ligne par ligne
    while (fgets(ligne, sizeof(ligne), f)) {
        
        int res = sscanf(ligne, "%d;%4[^;];%499[^;];%199[^;];%299[^;];%999[^;];%19s",
               &d.idPatient, d.groupeSanguin, d.antecedents,
               d.allergies, d.maladiesChroniques, d.notesMedicales, dateS);

        if (res >= 1 && d.idPatient == idRecherche) {
            trouve = 1;
            
            // Affichage sous forme de "Fiche Medicale"
            printf("\n" C_B_CYAN "    ============================================================\n" C_RESET);
            printf(C_B_WHITE "    D O S S I E R   M E D I C A L   D U   P A T I E N T   #" C_B_CYAN "%d\n" C_RESET, d.idPatient);
            printf(C_B_CYAN "    ============================================================\n" C_RESET);

            printf(C_WHITE "    " SYMB_POINT " GROUPE SANGUIN      : " C_B_CYAN "%s\n" C_RESET, d.groupeSanguin);
            printf(C_WHITE "    " SYMB_POINT " ANTECEDENTS         : " C_B_WHITE "%s\n" C_RESET, d.antecedents);
            printf(C_WHITE "    " SYMB_POINT " ALLERGIES           : " C_B_WHITE "%s\n" C_RESET, d.allergies);
            printf(C_WHITE "    " SYMB_POINT " MALADIES CHRONIQUES : " C_B_WHITE "%s\n" C_RESET, d.maladiesChroniques);
            printf(C_WHITE "    " SYMB_POINT " NOTES DU PRATICIEN  : " C_GRAY "%s\n" C_RESET, d.notesMedicales);
            printf(C_WHITE "    " SYMB_POINT " DATE D'OUVERTURE    : " C_B_WHITE "%s\n" C_RESET, dateS);

            printf(C_B_CYAN "    ============================================================\n" C_RESET);
            break; 
        }
    }
    fclose(f);

    if (!trouve) {
        printf(RED "\n    [ X ] Aucun dossier medical trouve pour l'identifiant #%d.\n" C_RESET, idRecherche);
    }

    printf("\n" C_GRAY "    [ Appuyez sur une touche pour revenir ]" C_RESET);
    _getch();
}

void afficherTousLesDossiers() {
    FILE *f = fopen("dossiers.txt", "r");
    char ligne[2048];
    int compteur = 0;

    system("cls");
    afficherEnteteElegante("R E P E R T O I R E   D E S   D O S S I E R S");

    if (f == NULL) {
        printf(RED "\n    [ ! ] Aucun dossier medical n'est enregistre dans la base.\n" C_RESET);
        printf(C_GRAY "    Appuyez sur une touche pour revenir..." C_RESET);
        _getch();
        return;
    }

    printf(C_GRAY "    %-5s %-6s %-12s %-25s %-20s\n", 
           "ID", "GR.", "OUVERTURE", "MALADIES CHRONIQUES", "ALLERGIES" C_RESET);
    printf(C_CYAN "    --------------------------------------------------------------------------------------\n" C_RESET);

    while (fgets(ligne, sizeof(ligne), f)) {
        int id;
        char grp[10], ant[500], all[200], mal[300], notes[500], dateStr[20];

        int res = sscanf(ligne, "%d;%9[^;];%499[^;];%199[^;];%299[^;];%499[^;];%19s",
                        &id, grp, ant, all, mal, notes, dateStr);

        if (res >= 6) {
            compteur++;
            printf(C_WHITE "    %-5d " C_B_CYAN "%-6s " C_GRAY "%-12s " C_WHITE "%-25.25s " C_B_WHITE "%-20.20s\n" C_RESET,
                   id, grp, dateStr, mal, all);
        }
    }

    printf(C_CYAN "    --------------------------------------------------------------------------------------\n" C_RESET);
    
    if (compteur == 0) {
        printf(C_GRAY "    La base de données est vide.\n" C_RESET);
    } else {
        printf(C_B_CYAN "    [ Total : %d dossier(s) affiche(s) ]\n" C_RESET, compteur);
    }

    fclose(f);
    printf(C_GRAY "\n    Appuyez sur une touche pour revenir au menu..." C_RESET);
    _getch();
}

// ==================== FONCTIONS CONSULTATION ====================

int genererIdConsultation() {
    FILE *f = fopen("consultations.txt", "r");
    int maxId = 0;
    if (f == NULL) return 1;

    char ligne[1024];
    while (fgets(ligne, sizeof(ligne), f)) {
        int id_lu = atoi(ligne); // Récupère le nombre avant le premier ';'
        if (id_lu > maxId) maxId = id_lu;
    }
    fclose(f);
    return maxId + 1;
}

void ajouterConsultation() {
    Consultation c;
    char dateS[20], heureS[20];
    
    // IMPORTANT : On calcule l'ID AVANT d'ouvrir le fichier en mode "a"
    c.id = genererIdConsultation(); 

    FILE *f = fopen("consultations.txt", "a"); // Mode "a" pour ajouter à la fin
    if (f == NULL) {
        printf("\n [!] ERREUR : Impossible d'ouvrir le fichier pour l'ecriture.\n");
        return;
    }

    printf(C_B_CYAN "\n    --- NOUVELLE CONSULTATION #%d ---\n" C_RESET, c.id);

    // Nettoyage systématique pour éviter que scanf ne saute des étapes
    printf(C_WHITE "    ID Patient          : " C_B_CYAN); 
    if(scanf("%d", &c.idPatient) != 1) { while(getchar() != '\n'); }

    printf(C_WHITE "    Nom Patient         : " C_B_CYAN); 
    scanf("%s", c.nomPatient);

    printf(C_WHITE "    Prenom Patient      : " C_B_CYAN); 
    scanf("%s", c.prenomPatient);

    printf(C_WHITE "    Date (AAAA-MM-DD)   : " C_B_CYAN); 
    scanf("%s", dateS);

    printf(C_WHITE "    Heure (HH:MM)       : " C_B_CYAN); 
    scanf("%s", heureS);
    while(getchar() != '\n'); 

    printf(C_WHITE "    Motif               : " C_B_CYAN); 
    fgets(c.motif, sizeof(c.motif), stdin);
    c.motif[strcspn(c.motif, "\n")] = 0; // Enlever le retour à la ligne

    printf(C_WHITE "    Diagnostic          : " C_B_CYAN); 
    fgets(c.diagnostic, sizeof(c.diagnostic), stdin);
    c.diagnostic[strcspn(c.diagnostic, "\n")] = 0;

    printf(C_WHITE "    Traitement          : " C_B_CYAN); 
    fgets(c.traitement, sizeof(c.traitement), stdin);
    c.traitement[strcspn(c.traitement, "\n")] = 0;

    printf(C_WHITE "    Tarif (DH)          : " C_B_CYAN); 
    scanf("%f", &c.tarif);

    // ECRITURE DANS LE FICHIER
    int resultat = fprintf(f, "%d;%d;%s;%s;%s;%s;%s;%s;%s;%.2f\n",
            c.id, c.idPatient, c.nomPatient, c.prenomPatient,
            dateS, heureS, c.motif, c.diagnostic, c.traitement, c.tarif);

    if (resultat > 0) {
        fflush(f); // Force l'écriture immédiate sur le disque
        printf(GREEN "\n    [ V ] Consultation enregistree ( %d octets ecrits).\n" CLR_RESET, resultat);
    } else {
        printf(RED "\n    [ X ] Erreur lors de l'ecriture physique.\n" CLR_RESET);
    }

    fclose(f);
    printf(C_GRAY "    Appuyez sur une touche pour continuer..." C_RESET);
    _getch();
}
void afficherConsultations() {
    FILE *f = fopen("consultations.txt", "r");
    if (f == NULL) {
        printf("\n    [ ! ] Aucun historique trouvé.\n");
        printf("    Appuyez sur une touche pour continuer...");
        _getch(); 
        return;
    }

    Consultation c;
    char dateS[20], heureS[10], motif[100], diag[100], trait[100];
    char ligne[1024];
    int count = 0;

    afficherEnteteElegante("H I S T O R I Q U E   C O N S U L T A T I O N S");
    printf(C_B_WHITE " %-4s | %-15s | %-12s | %-20s | %-8s\n", "ID", "PATIENT", "DATE", "DIAGNOSTIC", "TARIF");
    printf(C_CYAN " --------------------------------------------------------------------------\n" C_RESET);

    while (fgets(ligne, sizeof(ligne), f) != NULL) 
    {
        int champs = sscanf(ligne, "%d;%d;%49[^;];%49[^;];%14[^;];%9[^;];%99[^;];%99[^;];%99[^;];%f",
                           &c.id, &c.idPatient, c.nomPatient, c.prenomPatient,
                           dateS, heureS, motif, diag, trait, &c.tarif);

        if (champs == 10) {
            printf(C_WHITE " %-4d | %-15s | %-12s | %-20.20s | %7.2f DH\n" C_RESET,
                   c.id, c.nomPatient, dateS, diag, c.tarif);
            count++;
        }
    }

    printf(C_CYAN " --------------------------------------------------------------------------\n" C_RESET);
    fclose(f);
    
    printf(C_GRAY "\n    [ %d consultation(s) trouvée(s) ]\n" C_RESET, count);
    printf(C_B_CYAN "    >> Appuyez sur une TOUCHE pour revenir au menu..." C_RESET);
    
    _getch(); 
}
void rechercherConsultation() {
    int idCherche;
    clearScreen(); 
    afficherEnteteElegante("R E C H E R C H E   C O N S U L T A T I O N");
    
    printf("\n    Entrez l'ID de la consultation : " C_B_CYAN);
    if (scanf("%d", &idCherche) != 1) {
        while(getchar() != '\n'); // Nettoyer si l'utilisateur tape autre chose qu'un chiffre
        return;
    }

    FILE *f = fopen("consultations.txt", "r");
    if (!f) {
        printf(RED "\n    [ ! ] Erreur : Fichier introuvable.\n" CLR_RESET);
        printf("\n    Appuyez sur une touche pour revenir...");
        _getch();
        return;
    }

    char ligne[1024];
    int trouve = 0;
    while (fgets(ligne, sizeof(ligne), f)) {
        Consultation c;
        char dS[15], hS[10], mot[100], diag[100], trait[100];
        
        if (sscanf(ligne, "%d;%d;%49[^;];%49[^;];%14[^;];%9[^;];%99[^;];%99[^;];%99[^;];%f",
               &c.id, &c.idPatient, c.nomPatient, c.prenomPatient, dS, hS, 
               mot, diag, trait, &c.tarif) >= 1) {

            if (c.id == idCherche) {
                printf("\n" C_B_CYAN "    ============================================" CLR_RESET);
                printf("\n" C_B_WHITE "    DETAILS DE LA CONSULTATION #%d" CLR_RESET, c.id);
                printf("\n" C_B_CYAN "    ============================================" CLR_RESET);
                printf("\n    " SYMB_POINT " PATIENT     : " C_WHITE "%s %s (ID: %d)" CLR_RESET, c.nomPatient, c.prenomPatient, c.idPatient);
                printf("\n    " SYMB_POINT " DATE / HEURE: " C_WHITE "%s a %s" CLR_RESET, dS, hS);
                printf("\n    " SYMB_POINT " MOTIF       : " C_WHITE "%s" CLR_RESET, mot);
                printf("\n    " SYMB_POINT " DIAGNOSTIC  : " C_B_WHITE "%s" CLR_RESET, diag);
                printf("\n    " SYMB_POINT " TRAITEMENT  : " C_WHITE "%s" CLR_RESET, trait);
                printf("\n    " SYMB_POINT " TARIF       : " C_B_YELLOW "%.2f DH" CLR_RESET, c.tarif);
                printf("\n" C_B_CYAN "    ============================================\n" CLR_RESET);
                trouve = 1;
                break;
            }
        }
    }

    if (!trouve) {
        printf(RED "\n    [ X ] Aucune consultation trouvee avec l'ID %d.\n" CLR_RESET, idCherche);
    }

    fclose(f);

    printf(C_GRAY "\n    [ Appuyez sur une touche pour revenir au menu ]" C_RESET);
    
    while(getchar() != '\n'); 
    _getch();                 
}

void modifierConsultation() {
    int idModif, trouve = 0;
    FILE *f = fopen("consultations.txt", "r");
    FILE *temp = fopen("temp.txt", "w");

    if (!f || !temp) {
        printf("\n    [ ! ] Erreur d'ouverture du fichier.");
        if(f) fclose(f);
        return;
    }

    clearScreen();
    afficherEnteteElegante("M O D I F I E R   C O N S U L T A T I O N");
    printf("\n    Entrez l'ID de la consultation a modifier : ");
    scanf("%d", &idModif);

    char ligne[1024];
    while (fgets(ligne, sizeof(ligne), f)) {
        Consultation c;
        char dS[15], hS[10], mot[100], diag[100], trait[100];
        
        sscanf(ligne, "%d;%d;%49[^;];%49[^;];%14[^;];%9[^;];%99[^;];%99[^;];%99[^;];%f",
               &c.id, &c.idPatient, c.nomPatient, c.prenomPatient, dS, hS, 
               mot, diag, trait, &c.tarif);

        if (c.id == idModif) {
            trouve = 1;
            printf("\n" C_B_YELLOW "    --- MODIFICATION DES DONNEES ---" C_RESET);
            printf("\n    (Laissez vide pour ne pas modifier certaines chaines)\n");

            int choix;
            printf("\n    1. Modifier le Diagnostic (Actuel: %s)", diag);
            printf("\n    2. Modifier le Traitement (Actuel: %s)", trait);
            printf("\n    3. Modifier le Tarif      (Actuel: %.2f)", c.tarif);
            printf("\n    4. Tout modifier");
            printf("\n    Choix : ");
            scanf("%d", &choix);
            while(getchar() != '\n');

            if (choix == 1 || choix == 4) {
                printf("    Nouveau Diagnostic : "); fgets(diag, 100, stdin);
                diag[strcspn(diag, "\n")] = 0;
            }
            if (choix == 2 || choix == 4) {
                printf("    Nouveau Traitement : "); fgets(trait, 100, stdin);
                trait[strcspn(trait, "\n")] = 0;
            }
            if (choix == 3 || choix == 4) {
                printf("    Nouveau Tarif : "); scanf("%f", &c.tarif);
            }

            // On écrit la ligne modifiée dans le fichier temp
            fprintf(temp, "%d;%d;%s;%s;%s;%s;%s;%s;%s;%.2f\n",
                    c.id, c.idPatient, c.nomPatient, c.prenomPatient,
                    dS, hS, mot, diag, trait, c.tarif);
        } else {
            // On recopie la ligne originale sans changement
            fprintf(temp, "%s", ligne);
        }
    }

    fclose(f);
    fclose(temp);

    remove("consultations.txt");
    rename("temp.txt", "consultations.txt");

    if (trouve) printf(GREEN "\n    [ V ] Consultation mise a jour avec succes.\n" C_RESET);
    else printf(RED "\n    [ X ] ID introuvable.\n" C_RESET);

    printf(C_GRAY "    Appuyez sur une touche pour continuer..." C_RESET);
    while(getchar() != '\n');
    _getch();
}

void supprimerConsultation() {
    int idSuppr, trouve = 0;
    FILE *f = fopen("consultations.txt", "r");
    FILE *temp = fopen("temp.txt", "w");

    if (!f || !temp) {
        printf("\n    [ ! ] Erreur d'ouverture du fichier.");
        if(f) fclose(f);
        return;
    }

    clearScreen();
    afficherEnteteElegante("S U P P R I M E R   C O N S U L T A T I O N");
    printf("\n    ID de la consultation a supprimer : ");
    scanf("%d", &idSuppr);

    char ligne[1024];
    while (fgets(ligne, sizeof(ligne), f)) {
        int idLu = atoi(ligne); // On récupère l'ID au début de la ligne

        if (idLu == idSuppr) {
            trouve = 1; // On ne recopie pas cette ligne dans le fichier temp
            printf(C_B_YELLOW "\n    [ ! ] Consultation #%d supprimee.\n" C_RESET, idSuppr);
        } else {
            fprintf(temp, "%s", ligne);
        }
    }

    fclose(f);
    fclose(temp);

    remove("consultations.txt");
    rename("temp.txt", "consultations.txt");

    if (!trouve) printf(RED "\n    [ X ] Aucune consultation trouvee avec l'ID %d.\n" C_RESET, idSuppr);

    printf(C_GRAY "    Appuyez sur une touche pour continuer..." C_RESET);
    while(getchar() != '\n');
    _getch();
}

void EspaceMedecin() {
    if (!connexionMedecin()) {
        return; 
    }
    int M;
    int choix;
    
    do {
        system("cls");
        afficherEnteteElegante("E S P A C E   M E D E C I N");
        printf(C_GRAY "    Praticien : Dr. %-20s  |  Statut : Connecte\n\n" C_RESET, medecinPrincipal.nom);

        afficherLigneOption("1", "CONSULTATIONS ET DIAGNOSTICS");
        afficherLigneOption("2", "GESTION DES DOSSIERS MEDICAUX");
        afficherLigneOption("3", "GESTION DU PROFIL PRATICIEN");
        afficherLigneOption("4", "CALENDRIER DES RENDEZ-VOUS");
        
        printf("\n" C_GRAY "    ------------------------------------------------------------\n" C_RESET);
        afficherLigneOption("0", "FERMER LA SESSION MEDICALE");
        printf(C_GRAY "    ------------------------------------------------------------\n" C_RESET);

        promptElegante("Module");
        if (scanf("%d", &M) != 1) { while(getchar() != '\n'); continue; }
        getchar();

        switch(M) {
            case 1:
                do {
                    afficherEnteteElegante("M O D U L E   C O N S U L T A T I O N S");
                    afficherLigneOption("1", "Nouvelle consultation");
                    afficherLigneOption("2", "Historique complet");
                    afficherLigneOption("3", "Recherche par ID");
                    afficherLigneOption("4", "Modifier une consultation");
                    afficherLigneOption("5", "Supprimer une consultation");
                    afficherLigneOption("0", "Retour");
        
                    promptElegante("Choix");
                    if(scanf("%d", &choix) != 1) { while(getchar() != '\n'); continue; }

                    switch(choix) {
                        case 1: while(getchar() != '\n'); ajouterConsultation(); break;
                        case 2: afficherConsultations(); break;
                        case 3: rechercherConsultation(); break;
                        case 4: modifierConsultation(); break;
                        case 5: supprimerConsultation(); break;
                    }
                } while(choix != 0);
                break;

            case 2:
                do {
                    afficherEnteteElegante("D O S S I E R S   M E D I C A U X");
                    afficherLigneOption("1", "Creer un nouveau dossier");
                    afficherLigneOption("2", "Consulter un dossier");
                    afficherLigneOption("3", "Liste de tous les dossiers");
                    afficherLigneOption("0", "Retour");
                    
                    promptElegante("Choix");
                    if(scanf("%d", &choix) != 1) { while(getchar() != '\n'); continue; }
                    
                    if (choix == 1) creerDossierMedical();
                    else if (choix == 2) afficherDossierMedical();
                    else if (choix == 3) afficherTousLesDossiers();
                } while(choix != 0);
                break;
            case 3:
                do {
                    afficherEnteteElegante("P R O F I L   P R A T I C I E N");
                    afficherLigneOption("1", "Afficher le profil");
                    afficherLigneOption("2", "Modifier le profil");
                    printf("\n" C_GRAY "    ------------------------------------------------------------\n" C_RESET);
                    afficherLigneOption("0", "Retour au menu precedent");
                    printf(C_GRAY "    ------------------------------------------------------------\n" C_RESET);

                    promptElegante("Choix");
                    if (scanf("%d", &choix) != 1) { while(getchar() != '\n'); continue; }

                    switch(choix) {
                        case 1: afficherMedecin(); break;
                        case 2: modifierMedecin(); break;
                    }
                } while(choix != 0); 
                break;

            case 4:
                afficherRendezVousConfirmes();
                break;

            case 0:
                printf(C_GRAY "\n    Deconnexion de la session medicale...\n" C_RESET);
                medecinConnecteId = -1;
                Sleep(800);
                break;
        }
    } while(M != 0);
}
int main() {
    chargerPatients0();
    
    clearScreen();
    printf("\n\n\n\n");
    printf(C_B_WHITE "              S Y S T E M E   C L I N I Q U E\n" C_RESET);
    printf(C_CYAN    "              ===============================\n" C_RESET);
    printf(C_GRAY    "              Etablissement : El ALami\n");
    printf(C_GRAY    "              Statut : " C_B_CYAN "OPERATIONNEL\n\n" C_RESET);
    
    printf(C_GRAY "              Chargement des modules ");
    for(int i = 0; i < 3; i++) {
        printf(". ");
        Sleep(300); 
    }
    printf(C_B_CYAN " OK\n" C_RESET);
    
    printf("\n\n" C_GRAY "              [ Appuyez sur une touche pour entrer ]" C_RESET);
    _getch();

    int choix;
    do {
        afficherEnteteElegante("P O R T A I L   D' A C C U E I L");
        
        printf("\n" C_GRAY "    Veuillez selectionner un portail d'acces :\n\n" C_RESET);
        
        afficherLigneOption("1", "ESPACE PATIENT");
        afficherLigneOption("2", "ESPACE SECRETAIRE");
        afficherLigneOption("3", "ESPACE MEDECIN");
        
        printf("\n");
        printf(C_GRAY "    ------------------------------------------------------------\n" C_RESET);
        afficherLigneOption("0", "QUITTER LE SYSTEME");
        printf(C_GRAY "    ------------------------------------------------------------\n" C_RESET);

        printf("\n" C_BOLD C_CYAN "    Saisir votre choix > " C_RESET);
        
        if (scanf("%d", &choix) != 1) {
            while(getchar() != '\n'); 
            continue;
        }
        switch (choix) {
            case 1: 
                espacePatient(); 
                break;
            case 2: 
                espaceSecretaire(); 
                break;
            case 3: 
                EspaceMedecin(); 
                break;
            case 0: 
                clearScreen();
                printf("\n\n\n" C_B_WHITE "          S E S S I O N   T E R M I N E E\n" C_RESET);
                printf(C_CYAN "          ================================\n" C_RESET);
                printf(C_GRAY "          Deconnexion securisee effectuee.\n" C_RESET);
                Sleep(800);
                break;
            default: 
                printf(C_B_CYAN "\n    Code d'accès non reconnu.\n" C_RESET);
                Sleep(1000);
        }
    } while (choix != 0);
    
    return 0;
}
