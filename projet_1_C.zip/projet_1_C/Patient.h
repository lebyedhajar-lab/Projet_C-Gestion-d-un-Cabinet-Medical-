#ifndef PATIENT_H
#define PATIENT_H

#include "utils.h"
#include <stdio.h>

#define MAX_PATIENTS 100
#define FICHIER_PATIENTS "patients.txt"
#define FICHIER_DEMANDES_RDV "demandes_rdv.txt"

typedef struct {
    int id_patient;
    char nom[50];
    char prenom[50];
    char cin[15];
    char email[50];
    char date_naissance[20];
    char sexe[10];
    char mot_de_passe[20];
    char telephone[15];
    int actif;
} Patient;

typedef struct {
    int id_demande;
    int id_patient;
    char nom_patient[50];
    char prenom_patient[50];
    char date_souhaitee[20];
    char heure_souhaitee[10];
    char motif[100];
    char statut[20];  // "en attente", "confirmé", "refusé"
    char date_demande[20];
} DemandeRDV;

extern Patient patients[MAX_PATIENTS];
extern int nb_patients;

int verifierLogin(int id, const char *mot_de_passe);
int inscrireNouveauPatient();
int loginPatient();

int trouverPatient(int id);
void afficherPatient(int index);
void afficherMonProfil(int id_connecte);
void modifierMonProfil(int id_connecte);

void demanderRendezVous(int id_patient);
void afficherMesDemandesRDV(int id_patient);
void sauvegarderDemandeRDV(DemandeRDV demande);

void sauvegarderPatients();
void chargerPatients0();
int genererNouvelID();

void espacePatientConnecte(int id_patient);
void espacePatient();

#endif 
